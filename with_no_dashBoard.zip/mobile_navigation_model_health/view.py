"""
Route for the mobile navigation health check API
"""
from flask import Blueprint

from mobile_navigation_model_health.mobile_navigation_health import MobileNavigationHealthCheck

mobile_navigation_health_api = Blueprint('mobile_navigation_health_api', __name__)

mobile_navigation_health_api_view = MobileNavigationHealthCheck.as_view('mobile_navigation_health')
mobile_navigation_health_api.add_url_rule("/nav/ai/health", view_func=mobile_navigation_health_api_view, methods=['GET', ])
