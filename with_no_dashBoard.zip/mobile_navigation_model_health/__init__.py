"""GET /nav/ai/health - liveness probe."""
