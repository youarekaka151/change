"""
Liveness for nginx's readiness loop and the Docker HEALTHCHECK

It never loads a user model, so it answers as soon as the app can serve and a
slow first bundle load cannot hold nginx down.
"""

from flask import jsonify
from flask.views import MethodView

from common import service_registry
from common.responses import service_unavailable


class MobileNavigationHealthCheck(MethodView):
    """GET /nav/ai/health"""

    def get(self):
        if service_registry.prediction_service is None:
            return service_unavailable()
        return jsonify({'status': 'live'}), 200
