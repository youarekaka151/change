import copy
import glob
import json
import math
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import narrowing as NARROW  # noqa: E402

BUNDLE = os.getenv('NARROW_TEST_BUNDLE')          # a *_ocsvm.joblib
SESSIONS = os.getenv('NARROW_TEST_SESSIONS')      # folder of raw session *.json


def _load_session(path):
    """A bare session, or the app's upload envelope ({'username', 'sessions': [...]})."""
    raw = json.load(open(path, encoding='utf-8'))
    if 'sensor_samples' not in raw and isinstance(raw.get('sessions'), list):
        raw = raw['sessions'][0]
    return raw


def _same(a, b):
    a, b = float(a), float(b)
    return (math.isnan(a) and math.isnan(b)) or a == b


def test_renamed_keys_count_as_read():
    """interval_block(t, 'iv') -> 'iv_median' is read as 'touch_iv_median'."""
    assert 'iv_median' in NARROW.read_keys_for(('touch_iv_median',))


def test_tap_locked_copy_matches_vendor():
    """Fails when vendor extract_tap_locked changes: review tap_locked_narrow."""
    assert NARROW.tap_source_unchanged()


def test_tap_need_parses_and_refuses():
    need = NARROW.tap_need_for(['tap_acc_x_energy_idr', 'tap_acc_x_peak_median'])
    assert need == {'acc_x': frozenset({'energy', 'peak'})}
    assert NARROW.tap_need_for(['tap_n_used']) is None


def test_gates_inert_without_context():
    import new_feature_creation_session as V1
    NARROW.install()
    assert NARROW.READ_KEYS.get() is None
    vals = [0.1, 0.4, 0.2, 0.9, 0.3, 0.8]
    assert V1.stat_block(vals, 'x') == V1.stat_block.__wrapped__(vals, 'x')


@pytest.mark.skipif(not (BUNDLE and SESSIONS), reason='set NARROW_TEST_BUNDLE / NARROW_TEST_SESSIONS')
def test_narrow_gives_identical_selected_values(monkeypatch):
    import joblib
    import feature_extraction as FE
    NARROW.install()
    b = joblib.load(BUNDLE)
    cols, census = list(b['feature_columns']), b['frozen_state']['clean_census']
    for path in sorted(glob.glob(os.path.join(SESSIONS, '*.json'))):
        raw = _load_session(path)
        monkeypatch.setattr(FE, 'EXTRACT_NARROW', False)
        ref, _ = FE.extract_session(copy.deepcopy(raw), b['user_id'], None,
                                    census=census, columns=cols)
        monkeypatch.setattr(FE, 'EXTRACT_NARROW', True)
        got, diag = FE.extract_session(copy.deepcopy(raw), b['user_id'], None,
                                       census=census, columns=cols)
        assert diag['extract_narrow']
        bad = [c for c in cols if c not in got or not _same(got[c], ref[c])]
        assert not bad, (path, bad[:5])
