import os
import sys
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import vendor  # noqa: E402,F401  puts vendor/ on sys.path
import behavior_cleaner as BC  # noqa: E402
import new_adapid_schema as SCH  # noqa: E402


def clean_one(**fields):
    k = {"field_id": "f1", "key_down_ts": 1000, **fields}
    BC._fix_key_intervals({"key_events": [k]}, defaultdict(int))
    return k


def test_null_flag_with_normal_dwell_becomes_valid():
    k = clean_one(key_up_ts=1099, timing_valid=None)
    assert k["timing_valid"] is True and k["dwell_ms"] == 99


def test_missing_flag_behaves_as_before():
    assert clean_one(key_up_ts=1099)["timing_valid"] is True


def test_sub_floor_dwell_still_rejected():
    k = clean_one(key_up_ts=1010, timing_valid=None)
    assert k["timing_valid"] is False and k["key_class"] == "sub_floor"


def test_explicit_false_is_kept():
    assert clean_one(key_up_ts=1099, timing_valid=False)["timing_valid"] is False


def test_key_event_reads_null_flag_as_valid():
    k = SCH.KeyEvent({"key_down_ts": 1000, "key_up_ts": 1099, "timing_valid": None})
    assert k.timing_valid is True and k.dwell == 99


def test_touch_null_flag_is_cleaned_to_valid():
    s = {"touch_events": [{"touch_down_ts": 1000, "touch_up_ts": 1080, "timing_valid": None}]}
    BC._fix_touch_durations(s, defaultdict(int))
    assert s["touch_events"][0]["timing_valid"] is True
