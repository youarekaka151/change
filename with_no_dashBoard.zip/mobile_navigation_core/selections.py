"""Which feature selection this deployment trains with, and where its files live.

A SELECTION is the lab's list of feature columns (features/<dir>/selected_*.json).
A PROFILE names one selection and pins it in features/selections.json:

    "v6": {"file": "features/v3_v2/selected_V6_CONSENSUS_QUANTILE_CEILING_PROBE.json",
           "feature_set_sha256": "a5fb1772...",   sha256('\\n'.join(selected))
           "experimental": true,
           "dir_suffix": "_v6"}

ML_SELECTION picks the profile; unset, it is the registry's "default" (rev4).
That one variable is the whole switch:

  * enrolment trains new users on the profile's list (enrollment_service);
  * every profile has its OWN models/, templates/ and jobs/: the usual
    directories plus dir_suffix (models_v6/, /data/models_v6, ...). A folder
    therefore only ever holds one selection's bundles. A user enrolled under
    rev4 is enrolled again under v6 instead of being answered "exists", and
    switching back to rev4 finds its bundles untouched;
  * scoring needs no profile logic at all. Every bundle carries its own
    feature_columns, so the service just serves the profile's folders.

`experimental: true` lets a profile train from a selection that is not viable
or not deployable (a ceiling probe). Its bundles are served, tagged
model_uncertified with a warning, so they are never mistaken for certified
ones. The pinned list hash is what stops a hand-edited or swapped file from
being trained on silently: a mismatch refuses every enrolment.

Add a profile with add_selection.py rather than by hand; it computes the hash
and checks the columns against the live extractor first.

Standard library only: app.py and train_jobs.py import this on the request path.
"""

from __future__ import annotations

import hashlib
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))

ENV_VAR = 'ML_SELECTION'
REGISTRY_FILE = 'features/selections.json'
REGISTRY_PATH = os.path.join(HERE, *REGISTRY_FILE.split('/'))

NAME_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,31}$')
SUFFIX_RE = re.compile(r'^(|_[A-Za-z0-9][A-Za-z0-9_.-]{0,31})$')
SHA256_RE = re.compile(r'^[0-9a-f]{64}$')

_REGISTRIES = {}                    # abspath -> parsed registry, once per process


class SelectionConfigError(RuntimeError):
    """features/selections.json or ML_SELECTION is wrong. Nothing is served or
    trained until it is fixed: guessing a profile would serve one selection's
    folder under another's name."""


def feature_set_sha256(columns):
    """sha256('\\n'.join(columns)), the value every bundle records as
    provenance.feature_set_sha256 (package_ml_bundle.feature_set_sha256)."""
    return hashlib.sha256('\n'.join(columns).encode('utf-8')).hexdigest()


# =============================================================================
#  the registry
# =============================================================================

def parse_registry(obj, root=HERE):
    """
    Validate a registry object. Returns {'default': name, 'profiles': {...}}.

    Each profile comes back with 'name', and 'path' (the selection file
    resolved against `root`). Raises SelectionConfigError on anything wrong,
    naming the profile and the field.
    """
    if not isinstance(obj, dict) or not isinstance(obj.get('profiles'), dict) \
            or not obj['profiles']:
        raise SelectionConfigError('%s needs a non-empty "profiles" object'
                                   % REGISTRY_FILE)
    profiles, suffixes = {}, {}
    for name, raw in obj['profiles'].items():
        where = '%s, profile %r' % (REGISTRY_FILE, name)
        if not NAME_RE.match(name):
            raise SelectionConfigError('%s: a name is letters, digits, "_", '
                                       '"." or "-", at most 32' % where)
        if not isinstance(raw, dict):
            raise SelectionConfigError('%s: not an object' % where)

        file = raw.get('file')
        if not isinstance(file, str) or not file.startswith('features/') \
                or '\\' in file or '..' in file.split('/'):
            raise SelectionConfigError(
                '%s: "file" must be a path under features/ with forward '
                'slashes, e.g. features/v3/selected_rev4.json' % where)
        pin = raw.get('feature_set_sha256')
        if not isinstance(pin, str) or not SHA256_RE.match(pin):
            raise SelectionConfigError('%s: "feature_set_sha256" must be 64 '
                                       'lower-case hex digits' % where)
        experimental = raw.get('experimental', False)
        if not isinstance(experimental, bool):
            raise SelectionConfigError('%s: "experimental" must be true or '
                                       'false' % where)
        suffix = raw.get('dir_suffix')
        if not isinstance(suffix, str) or not SUFFIX_RE.match(suffix):
            raise SelectionConfigError('%s: "dir_suffix" must be "" or "_" '
                                       'followed by a name, e.g. "_v6"' % where)
        if suffix in suffixes:
            raise SelectionConfigError(
                '%s: dir_suffix %r is already used by %r. Two selections '
                'would publish into one models folder.'
                % (where, suffix, suffixes[suffix]))
        suffixes[suffix] = name

        profiles[name] = dict(raw, name=name, experimental=experimental,
                              path=os.path.join(root, *file.split('/')))

    default = obj.get('default')
    if default not in profiles:
        raise SelectionConfigError('%s: "default" is %r, which is not a '
                                   'profile' % (REGISTRY_FILE, default))
    return {'default': default, 'profiles': profiles}


def load_registry(path=REGISTRY_PATH):
    """
    The parsed registry, read once per process: switching or adding a profile
    takes a restart, like any other configuration change. A profile's paths
    resolve against the directory above features/.
    """
    key = os.path.abspath(path)
    if key not in _REGISTRIES:
        try:
            with open(key, 'r', encoding='utf-8') as fh:
                obj = json.load(fh)
        except (OSError, ValueError) as error:
            raise SelectionConfigError('cannot read %s: %s' % (key, error))
        _REGISTRIES[key] = parse_registry(
            obj, root=os.path.dirname(os.path.dirname(key)))
    return _REGISTRIES[key]


def active(registry=None):
    """The profile ML_SELECTION names (unset: the registry's default)."""
    registry = registry or load_registry()
    name = (os.getenv(ENV_VAR) or '').strip() or registry['default']
    profile = registry['profiles'].get(name)
    if profile is None:
        raise SelectionConfigError(
            '%s=%r is not a profile in %s. Known: %s.'
            % (ENV_VAR, name, REGISTRY_FILE, ', '.join(sorted(registry['profiles']))))
    return profile


# =============================================================================
#  the folders
# =============================================================================

def _with_suffix(env_var, default, suffix):
    base = os.getenv(env_var, default)
    return (base.rstrip('/\\') or base) + suffix


def dirs_for(profile):
    """(models, templates, jobs) of any profile: the ML_*_DIR values (or their
    defaults) plus the profile's dir_suffix."""
    suffix = profile['dir_suffix']
    return (_with_suffix('ML_MODELS_DIR', 'models', suffix),
            _with_suffix('ML_TEMPLATES_DIR', 'templates', suffix),
            _with_suffix('ML_JOBS_DIR', 'jobs', suffix))


def models_dir():
    return dirs_for(active())[0]


def templates_dir():
    return dirs_for(active())[1]


def jobs_dir():
    return dirs_for(active())[2]


def describe(profile=None):
    """Scalars only, for logs and /nav/ai/info."""
    profile = profile or active()
    return {'name': profile['name'],
            'file': profile['file'],
            'feature_set_sha256': profile['feature_set_sha256'][:16],
            'experimental': profile['experimental'],
            'dir_suffix': profile['dir_suffix']}
