"""Change 3 (ML_EXTRACT_NARROW=1): skip helper work whose outputs no model column reads.

install() wraps twelve prefix-based vendor helpers ONCE, at import. A wrapper does
NOTHING unless the current request has set READ_KEYS - feature_extraction does so
only around the selected-family loop of one extraction - so training, enrolment,
the research CLIs and the full extraction run the original helpers.

When active, a helper call runs for real only if one of its output keys is read.
Otherwise it returns the helper's own empty-input result: the same zero-filled key
set the families already produce for a missing channel.

tap_locked_narrow() is a copy of vendor extract_tap_locked restricted to the
(channel, metric) pairs the model reads. It is switched off automatically if the
vendor method's source changes (TAP_LOCKED_SOURCE_SHA256).
"""
from __future__ import annotations

import contextvars
import hashlib
import inspect
import logging
import os
import sys
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import vendor                                   # noqa: E402,F401  puts vendor/ on sys.path
import new_feature_creation_session as V1      # noqa: E402
import new_feature_creation_session_v2 as V2   # noqa: E402,F401  must be imported BEFORE install():
                                                #   it installs the 10-key _agg_block that is wrapped
import derived_features as DF                   # noqa: E402

logger = logging.getLogger(__name__)

# The request's read keys: the bundle's columns plus every '_'-suffix of them.
# A ContextVar is per greenlet under gunicorn's gevent workers, so one request
# never switches gating on for another.
READ_KEYS = contextvars.ContextVar('nav_read_keys', default=None)

# ---------------------------------------------------------------- Part A ----
_EMPTY = np.array([])
GATED = {
    'stat_block':             (V1, {'values': _EMPTY}),
    'spectral_block':         (V1, {'values': _EMPTY}),
    'wavelet_block':          (V1, {'values': _EMPTY}),
    'complexity_block':       (V1, {'values': _EMPTY}),
    'shape_block':            (V1, {'xs': _EMPTY, 'ys': _EMPTY}),
    'interval_block':         (V1, {'times': _EMPTY}),
    '_agg_block':             (V1, {'values': []}),
    '_lag_features':          (V1, {'a': _EMPTY, 'b': _EMPTY}),
    'contact_geometry':       (DF, {'touches': []}),
    'world_frame':            (DF, {'lin_xyz': [], 'grav_xyz': [], 'quat': None}),
    'interval_dynamics':      (DF, {'intervals': []}),
    'spectral_entropy_block': (DF, {'values': [], 'fs': None}),
}
_NOT_KEY = ('fs', 'hz')            # data-dependent arguments that never change the key set
_KEYS = {}                         # (helper, non-data arguments) -> frozenset of output keys
_INSTALLED = False


def _gate(name, real, empty):
    sig = inspect.signature(real)

    def gated(*args, **kwargs):
        read = READ_KEYS.get()
        if read is None:                               # not inside a narrowed extraction
            return real(*args, **kwargs)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        a = bound.arguments
        ck = (name,) + tuple((k, repr(v)) for k, v in sorted(a.items())
                             if k not in empty and k not in _NOT_KEY)
        keys = _KEYS.get(ck)
        zero = None
        if keys is None:
            try:
                zero = real(**{**a, **empty})
            except Exception:                           # noqa: BLE001  cannot tell: compute
                return real(*args, **kwargs)
            keys = _KEYS.setdefault(ck, frozenset(zero))
        if keys & read:
            return real(*args, **kwargs)               # read: the real computation
        return zero if zero is not None else real(**{**a, **empty})

    gated.__wrapped__ = real
    gated.__name__ = name
    return gated


def install():
    """Wrap the helpers once. Idempotent. Inert until READ_KEYS is set."""
    global _INSTALLED
    if _INSTALLED:
        return
    for name, (module, empty) in GATED.items():
        setattr(module, name, _gate(name, getattr(module, name), empty))
    _INSTALLED = True


def read_keys_for(columns):
    """The columns plus every '_'-suffix of each (catches families that rename keys,
    e.g. interval_block(t, 'iv') -> 'iv_median', read as 'touch_iv_median')."""
    read = set(columns)
    for c in columns:
        read.update(c[i + 1:] for i, ch in enumerate(c) if ch == '_')
    return frozenset(read)


# ---------------------------------------------------------------- Part B ----
# sha256 of inspect.getsource(V1.SessionFeatureExtractor.extract_tap_locked) that
# tap_locked_narrow() was copied from (vendor/new_feature_creation_session.py:2508-2597).
TAP_LOCKED_SOURCE_SHA256 = '9a294b55bd2def47713820922a7c278e6f748cd48f639d5763047c9115842c53'

TAP_CHANNELS = ('acc_mag', 'gyro_mag', 'acc_x', 'acc_y', 'acc_z', 'gyro_x', 'gyro_y', 'gyro_z')
TAP_METRICS = ('peak', 'ttp_ms', 'energy', 'rms', 'settle_ms', 'recovery', 'post_var', 'pre_var')


def tap_source_unchanged():
    src = inspect.getsource(V1.SessionFeatureExtractor.extract_tap_locked)
    return hashlib.sha256(src.encode()).hexdigest() == TAP_LOCKED_SOURCE_SHA256


def tap_need_for(tap_locked_columns):
    """{channel: frozenset(metrics)} the model reads from tap_locked, or None to
    run the original method (nothing selected, an unparseable column such as
    tap_n_used, or vendor extract_tap_locked has changed)."""
    if not tap_locked_columns:
        return None
    need = {}
    for c in tap_locked_columns:
        hit = [(ch, m) for ch in TAP_CHANNELS for m in TAP_METRICS
               if c.startswith(f'tap_{ch}_{m}_')]
        if len(hit) != 1:
            return None
        need.setdefault(hit[0][0], set()).add(hit[0][1])
    if not tap_source_unchanged():
        logger.error('vendor extract_tap_locked changed since narrowing.tap_locked_narrow '
                     'was copied from it: running the original. Review narrowing.py.')
        return None
    return {ch: frozenset(ms) for ch, ms in need.items()}


def tap_locked_narrow(self, view, need):
    """vendor extract_tap_locked, line for line, except the lines marked NARROWED."""
    f = {}
    shorts = [s for s in ('acc', 'gyro') if view.has(s)]
    if not shorts or not view.touches:
        f.update(V1._zero_like(self._tap_keys()))
        f['tap_n_used'] = 0.0
        return f

    pre_ms, post_ms = 150.0, 400.0
    channels = [('acc', 'mag'), ('gyro', 'mag')]
    if view.has('acc'):
        channels += [('acc', 'x'), ('acc', 'y'), ('acc', 'z')]
    if view.has('gyro'):
        channels += [('gyro', 'x'), ('gyro', 'y'), ('gyro', 'z')]
    channels = [(s, ax) for s, ax in channels if f'{s}_{ax}' in need]          # NARROWED

    per_channel = {f'{s}_{ax}': defaultdict(list) for s, ax in channels}
    for touch in view.touches:
        t0 = touch.t_down
        if not np.isfinite(t0):
            continue
        for s, ax in channels:
            st = view.streams.get(s)
            if st is None:
                continue
            idx = st.slice_time(t0 - pre_ms, t0 + post_ms)
            if idx.size < 6:
                continue
            vals = (st.mag[idx] if ax == 'mag' else st.xyz[idx, 'xyz'.index(ax)])
            times = st.t[idx]
            m = np.isfinite(vals)
            if m.sum() < 6:
                continue
            vals, times = vals[m], times[m]
            pre = vals[times < t0]
            post = vals[times >= t0]
            if post.size < 3:
                continue
            want = need[f'{s}_{ax}']                                            # NARROWED
            base = float(np.median(pre)) if pre.size >= 2 else float(post[0])
            dev = post - base
            adev = np.abs(dev)
            peak_i = int(np.argmax(adev))
            peak = float(adev[peak_i])
            d = per_channel[f'{s}_{ax}']
            if 'peak' in want:                                                  # NARROWED
                d['peak'].append(peak)
            if 'ttp_ms' in want:                                                # NARROWED
                d['ttp_ms'].append(float(times[times >= t0][peak_i] - t0))
            if 'energy' in want:                                                # NARROWED
                d['energy'].append(float(np.sum(dev ** 2)))
            if 'rms' in want:                                                   # NARROWED
                d['rms'].append(V1.rms(dev))
            if 'settle_ms' in want:                                             # NARROWED
                d['settle_ms'].append(V1._settle_time(times[times >= t0] - t0, adev, peak))
            if 'recovery' in want:                                              # NARROWED
                tail = adev[max(1, int(0.7 * adev.size)):]
                d['recovery'].append(V1.safe_ratio(peak - V1.safe_mean(tail), peak)
                                     if peak > 1e-9 else 0.0)
            if 'post_var' in want:                                              # NARROWED
                d['post_var'].append(V1.safe_std(post))
            if 'pre_var' in want:                                               # NARROWED
                d['pre_var'].append(V1.safe_std(pre) if pre.size >= 2 else 0.0)

    for name, d in per_channel.items():
        for metric in need[name]:                                               # NARROWED
            f.update(V1._agg_block(d.get(metric, []), f'tap_{name}_{metric}'))  # the 10-key one
    return f
