"""The mobile navigation ML engine: everything that is not an HTTP concern.

    prediction_service.py   scoring a session against a user's model
    enrollment_service.py   the 11-step fetch -> templates -> features -> fit
                            -> gate -> publish pipeline
    bundle_loader.py        loading and caching model + template bundles
    feature_extraction.py   turning a raw session into the model's ~50 features
    selections.py           which feature selection is active (features/)
    boot_checks.py          refuses to start on a broken feature tree
    vendor/                 the verbatim research code
    features/               the selection profiles selections.py reads

Importing this package puts its own directory on sys.path, so these modules go
on importing each other by plain name (`import selections`, `from bundle_loader
import BundleStore`). That is deliberate: the vendored modules are verbatim
copies that import each other as flat siblings, so the directory has to be
importable as a root.
"""

import os
import sys

CORE_DIR = os.path.dirname(os.path.abspath(__file__))

if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)
