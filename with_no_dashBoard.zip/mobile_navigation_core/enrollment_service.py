"""In-server enrolment: one user's genuine sessions -> one deployable bundle.

This module owns NO feature logic and NO training logic. Like
feature_extraction.py it is a call sequence over the vendored research code,
in the order the research pipeline ran it:

    new_build_dtw_templates.build_for_user       DTW templates
    new_feature_creation_session_v2.SessionPipelineV2.run
                                                 training / testing CSVs
    behavior_cleaner.build_census                the frozen per-user census
    new_train_session.SessionOCSVM.fit           model + calibrated threshold
    package_ml_bundle (pure helpers only)        provenance

That sequence, run on the research dumps, reproduces the 8 deployed bundles
(tests/test_enrollment_parity.py). What this module adds is only what the
research loop left to a human: it REFUSES instead of degrading. The vendored
trainer silently zero-fills NaN/inf, silently drops a selected column that is
constant for this user, and silently leaves the threshold at an uncalibrated
0.0 when it has too few rows - research measured FRR 1.000 at that threshold.
Every one of those is checked here, before the step that would hide it
(ENROLLMENT_PLAN.md section 7).

Nothing here runs inside a gunicorn request. train_jobs.py calls it from its
own process.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import logging
import math
import os
import random
import shutil
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import http.client

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import vendor                                   # noqa: E402,F401  puts vendor/ on sys.path

import joblib                                   # noqa: E402
import numpy as np                              # noqa: E402
import pandas as pd                             # noqa: E402
import sklearn                                  # noqa: E402

import behavior_cleaner as BC                   # noqa: E402
import new_build_dtw_templates as DTW           # noqa: E402
import payload_canonicalizer as CANON           # noqa: E402
import new_feature_creation_session_v2 as V2    # noqa: E402
import new_train_session as TR                  # noqa: E402
# package_ml_bundle.py's docstring says "research directory only - NEVER
# shipped". That is stale, but the file is vendored verbatim, so it stays. Only
# its pure helpers are called (load_selection, needs_census_for,
# feature_set_sha256, match_selection). Never package_user, build_user_census
# or contaminated_flag: they read research paths, raise SystemExit and cache
# without bound.
import package_ml_bundle as PKG                 # noqa: E402

from dotenv import load_dotenv
load_dotenv()
import selections as SEL                        # noqa: E402
from bundle_loader import ArtifactError, BundleStore   # noqa: E402
from feature_extraction import ExtractionError         # noqa: E402
from train_jobs import jobs_dir, valid_user_id         # noqa: E402,F401

logger = logging.getLogger(__name__)

# ---- the selection -----------------------------------------------------------
# Which feature list enrolment trains on is a profile in features/selections.json,
# chosen by ML_SELECTION (selections.py). The default, rev4, is pinned to the
# list hash all 8 research-built bundles record, and records the same
# selection_file string they do.

# ---- training settings ------------------------------------------------------
# Stored in no bundle. Recovered from the 8 deployed ones: every threshold is
# sorted(loo_scores)[floor(0.05 * n)], and the vendored trainer refits all 8
# bit-exact with exactly these two values. fit()'s own default is
# calibrate_frr=None -> threshold 0.0.
CALIBRATE_FRR = 0.05
CALIBRATE_METHOD = 'temporal'

# ---- gate floors (ENROLLMENT_PLAN.md section 7) -----------------------------
# SessionOCSVM._calibrate returns 0.0 and leaves loo_scores None below 6 rows
# or below 3 temporal scores. These are its floors, not new statistics.
MIN_TRAIN_ROWS = 6
MIN_LOO_SCORES = 3
LOO_PTP_TOL = 1e-9

# ---- unavailable features (payload_canonicalizer availability) --------------
# A selected feature can be constant for a user for two very different reasons:
#   * its input does not exist in this user's app - no re-enter field, no login
#     screen, an SDK that never reports scroll gestures. Nothing is broken; the
#     feature cannot be built here. It is DROPPED from this user's model, with
#     the reason recorded in the bundle (provenance.features_unavailable).
#   * anything else. That is a broken pipeline or broken data, and enrolment
#     still REFUSES with features_constant, exactly as before.
# A model needs most of its selection to mean anything: below this fraction of
# the selected features available, refuse rather than train a stub.
MIN_AVAILABLE_FRACTION = 0.5

ENVELOPE_NAME = 'sessions.json'     # a fixed name, never the raw user id

# ---- fetching from NAV --------------------------------------------------------
PAGE_SIZE = 10                      # what new_data_fetching.py paged with
READ_TIMEOUT_S = 300                # one page of 10 sessions with events is ~90 MB
PAGE_ATTEMPTS = 6
RETRY_STATUS = (429, 500, 502, 503, 504)


class Refused(Exception):
    """The gate said no. Nothing is published; status reason `refused:<code>`."""

    def __init__(self, code, detail=''):
        super().__init__('%s: %s' % (code, detail) if detail else code)
        self.code = code
        self.detail = detail

    @property
    def reason(self):
        return 'refused:%s' % self.code


class Retryable(Exception):
    """Not the user's fault and not the data's: NAV down, not configured, or an
    incomplete read. train_jobs re-queues it with backoff."""


# ---- runtime configuration (env only; nothing is baked into the image) --------

def models_dir():
    """ML_MODELS_DIR (default models) + the active selection's dir_suffix."""
    return SEL.models_dir()


def templates_dir():
    """ML_TEMPLATES_DIR (default templates) + the active selection's dir_suffix."""
    return SEL.templates_dir()


def nav_base_url():
    """e.g. https://nav.example/nav/back/api/v1 - no default, on purpose."""
    # print(f"the NAV_API_BASE_URL is = {os.getenv('NAV_API_BASE_URL')}--------")
    return (os.getenv('NAV_API_BASE_URL') or '').strip().rstrip('/')


def nav_api_key():
    return os.getenv('NAV_API_KEY') or ''


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def trainer_sha256():
    """sha256 of the trainer this build actually ran, for bundle provenance."""
    return _sha256_file(TR.__file__)


# =============================================================================
#  gate 1 - the selection file
# =============================================================================

def active_profile():
    """The selection profile ML_SELECTION names, or Refused('selection_config')."""
    try:
        return SEL.active()
    except SEL.SelectionConfigError as error:
        raise Refused('selection_config', str(error))


def check_selection(profile=None):
    """
    (columns, selection dict, file sha256), or Refused. Run before anything.

    `profile` defaults to the active one. Its file must hold exactly the list
    pinned for it in features/selections.json. Only a profile marked
    experimental may name a selection that is not viable.
    """
    profile = profile or active_profile()
    path = profile['path']
    try:
        selection = PKG.load_selection(path)
    except (OSError, ValueError) as error:
        raise Refused('selection_unreadable', str(error))
    cols = selection.get('selected') if isinstance(selection, dict) else None
    if not isinstance(cols, list) or not cols \
            or not all(isinstance(c, str) and c for c in cols):
        raise Refused('selection_count', '%s holds no list of feature names'
                      % profile['file'])
    if len(set(cols)) != len(cols):
        raise Refused('selection_count', '%s names a feature twice' % profile['file'])
    if PKG.feature_set_sha256(cols) != profile['feature_set_sha256']:
        raise Refused('selection_hash', '%s is not the list pinned for selection '
                      '%r in %s' % (profile['file'], profile['name'], SEL.REGISTRY_FILE))
    viable = selection.get('viable') is True
    if not viable and not profile['experimental']:
        raise Refused('selection_not_viable', '%s records viable=%r; only a profile '
                      'marked experimental may train from it'
                      % (profile['file'], selection.get('viable')))
    # The trainer reads the file with its own reader; it must see the same list.
    # That reader refuses any non-viable file outright, so an experimental probe
    # skips it: training takes the list from here (feature_columns(df,
    # feature_list=cols)), never from the file.
    if viable and TR.load_feature_list(path) != cols:
        raise Refused('selection_reader_mismatch')
    return list(cols), selection, _sha256_file(path)


# =============================================================================
#  step 2 - the shared eligible-session rule (ENROLLMENT_PLAN.md section 5)
# =============================================================================
# Must select exactly what NAV's ENROL_PREDICATE counts:
#
#   LOWER(TRIM(s.session_type)) = 'enrollment'
#   AND NVL(LOWER(TRIM(s.label)), 'genuine') = 'genuine'
#   AND NVL(s.schema_version, 1) >= 2
#   AND (s.operator_id IS NULL OR LOWER(TRIM(s.operator_id)) = LOWER(TRIM(p.user_id)))
#
# Oracle stores '' as NULL and TRIM of an all-blank string is NULL, which is why
# a blank label counts as genuine below, and a blank-but-not-empty operator_id
# (TRIM -> NULL, NULL = x -> not true) does not match.

def _trim_lower(value):
    return str(value).strip().lower() if value is not None else ''


def is_eligible(session, user_id):
    """True iff this backend session dict is a genuine enrolment of user_id."""
    if not isinstance(session, dict):
        return False
    if _trim_lower(session.get('session_type')) != 'enrollment':
        return False
    if (_trim_lower(session.get('session_label')) or 'genuine') != 'genuine':
        return False
    version = session.get('schema_version')
    try:
        version = 1.0 if version is None else float(version)
    except (TypeError, ValueError):
        return False
    if not version >= 2:
        return False
    operator = session.get('operator_id')
    if operator is None or operator == '':
        return True
    return _trim_lower(operator) == _trim_lower(user_id)


def is_unreadable(session):
    """
    A session new_adapid_schema.SessionView would RAISE on, for the whole user.

    NAV returns `sensor_events` (the v1 shape, often just []) for any session
    with no sensor_samples rows, keeping its stored schema_version - so the
    schema_version term above does not catch it, and SessionView refuses any
    session whose sensor_events is not None. Such a session has no sensor
    streams at all; if it could be read, the sanitizer would EXCLUDE it
    (MIN_CORE_SAMPLES). Skipping it is therefore the same outcome, counted in
    `n_unreadable`, instead of an enrolment that fails for ever.
    """
    return not session.get('sensor_samples') and session.get('sensor_events') is not None


# =============================================================================
#  step 1 - fetch from NAV's own read endpoint
# =============================================================================

class FetchError(RuntimeError):
    """NAV answered, and the answer cannot be trained on. Not retried."""


def _now_iso():
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec='seconds')


class NavFetch:
    """
    Pages GET {NAV_API_BASE_URL}/behavioral/sessions/<user>?include_events=1&limit=10&offset=N
    with X-API-Key. That is the endpoint new_data_fetching.py built the research
    corpus from, so sessions arrive in exactly the shape the models were trained on.

    Where research only warned, this raises: a page that keeps failing, a
    profile that changes between pages, a tripped page guard, or fewer sessions
    collected than the first page's total_sessions (which counts ALL of the
    profile's sessions, attacks included, so it is compared before filtering).
    Training on a partial history is never an option.

    Pages are newest-first (created_at DESC), so a session inserted during the
    fetch shifts later pages by one: the duplicate is dropped by session_id and
    nothing is skipped. NAV never sends Retry-After, hence jittered backoff.
    """

    def __init__(self, user_id, base_url=None, api_key=None, sleep=time.sleep):
        self.user_id = user_id
        self.base_url = (nav_base_url() if base_url is None
                         else base_url.strip().rstrip('/'))
        self.api_key = nav_api_key() if api_key is None else api_key
        self.profile = None
        self.total = None
        self.pages = 0
        self.n_collected = 0
        self.fetched_at = None
        self._sleep = sleep
        if not self.base_url or not self.api_key:
            raise Retryable('nav_not_configured: set NAV_API_BASE_URL and '
                            'NAV_API_KEY, then restart')
        if urllib.parse.urlsplit(self.base_url).scheme not in ('http', 'https'):
            raise Retryable('nav_not_configured: NAV_API_BASE_URL must be http(s)')

    def url(self, offset):
        return ('%s/behavioral/sessions/%s?include_events=1&limit=%d&offset=%d'
                % (self.base_url, urllib.parse.quote(self.user_id, safe=''),
                   PAGE_SIZE, offset))

    def _get(self, offset):
        request = urllib.request.Request(
            self.url(offset),
            headers={'X-API-Key': self.api_key, 'Accept': 'application/json'})
        last = None
        for attempt in range(PAGE_ATTEMPTS):
            if attempt:
                self._sleep(min(60.0, 2.0 ** attempt) * (0.5 + random.random()))
            try:
                with urllib.request.urlopen(request, timeout=READ_TIMEOUT_S) as resp:
                    body = resp.read()
                return json.loads(body)
            except urllib.error.HTTPError as error:
                if error.code in RETRY_STATUS:
                    last = 'HTTP %d' % error.code
                    continue
                if error.code in (401, 403):
                    # A wrong or missing key is configuration, not the user.
                    raise Retryable('nav_auth: HTTP %d, check NAV_API_KEY'
                                    % error.code)
                raise FetchError('nav_http_%d' % error.code)
            except (OSError, http.client.HTTPException, ValueError) as error:
                # OSError covers URLError, refused/reset connections and read
                # timeouts; ValueError a truncated or non-JSON body.
                last = '%s: %s' % (type(error).__name__, str(error)[:200])
        raise Retryable('nav_unreachable: offset %d failed %d times, last %s'
                        % (offset, PAGE_ATTEMPTS, last))

    def sessions(self):
        """Yield every session of the user once, exactly as NAV returned it."""
        seen = set()
        offset = 0
        guard = None
        while True:
            body = self._get(offset)
            data = body.get('data') if isinstance(body, dict) else None
            if body.get('success') is not True or not isinstance(data, dict) \
                    or not isinstance(data.get('sessions'), list):
                raise FetchError('nav_bad_envelope at offset %d' % offset)

            profile = data.get('profile')
            if not isinstance(profile, dict) or profile.get('id') is None:
                raise FetchError('nav_no_profile for %r' % self.user_id)
            if self.profile is None:
                if profile.get('user_id') != self.user_id:
                    raise FetchError('nav_profile_user_mismatch: %r'
                                     % profile.get('user_id'))
                self.profile = profile
                self.total = int(data.get('total_sessions') or 0)
                self.fetched_at = _now_iso()
                guard = math.ceil(self.total / PAGE_SIZE) + 2
            elif profile.get('id') != self.profile.get('id'):
                raise Retryable('nav_profile_changed during the fetch')

            page = data['sessions']
            self.pages += 1
            print('[FETCH] %s: page %d, offset=%d, got %d session(s), total_sessions=%s'
                  % (self.user_id, self.pages, offset, len(page), self.total),
                  flush=True)
            for session in page:
                sid = session.get('session_id') if isinstance(session, dict) else None
                if not sid:
                    raise FetchError('nav_session_without_id at offset %d' % offset)
                if sid in seen:
                    continue
                seen.add(sid)
                self.n_collected += 1
                yield session

            if len(page) < PAGE_SIZE:
                break
            if self.pages >= guard:
                raise Retryable('page guard tripped: %d pages for %d sessions'
                                % (self.pages, self.total))
            offset += PAGE_SIZE

        if self.n_collected < self.total:
            raise Retryable('incomplete fetch: %d of %d sessions'
                            % (self.n_collected, self.total))


# =============================================================================
#  step 3 - the temp file the vendored drivers read
# =============================================================================

class EnvelopeWriter:
    """
    Writes {"data": {"sessions": [...], "user_id", "profile", ...}} one session
    at a time, so a user's whole history is never held in memory here.

    Same envelope new_data_fetching.py wrote (minus its `_fetch` block, which
    nothing in vendor/ reads). `sessions` is deliberately the FIRST key:
    behavior_cleaner.SessionStream takes the first `"sessions": [` in the file,
    so nothing may come before it that could contain one. Session dicts are
    written exactly as the backend returned them.
    """

    def __init__(self, path):
        self.path = path
        self.n = 0
        self._fh = open(path, 'x', encoding='utf-8')
        self._fh.write('{"data": {"sessions": [')

    def add(self, session):
        self._fh.write(',\n' if self.n else '\n')
        self._fh.write(json.dumps(session))
        self.n += 1

    def close(self, user_id, profile):
        tail = {'user_id': user_id, 'profile': profile,
                'total_sessions': self.n, 'returned_sessions': self.n,
                'include_events': True}
        self._fh.write('\n], ')
        self._fh.write(json.dumps(tail)[1:])        # '"user_id": ...}' + '}'
        self._fh.write('}\n')
        self._fh.close()
        return self.n

    def abort(self):
        if not self._fh.closed:
            self._fh.close()


# =============================================================================
#  gates 3-6
# =============================================================================

def _gate_training_frame(df, cols):
    """Gates 3, 4, 5 - before feature_columns / _matrix can hide anything."""
    if len(df) < MIN_TRAIN_ROWS:
        raise Refused('too_few_training_rows',
                      '%d training row(s) after sanitizer and holdout, need %d'
                      % (len(df), MIN_TRAIN_ROWS))

    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise Refused('features_missing', '%d absent, e.g. %s'
                      % (len(missing), missing[:3]))

    try:
        block = df[cols].astype(float)
    except (TypeError, ValueError) as error:
        raise Refused('features_non_numeric', str(error)[:200])

    finite = np.isfinite(block.to_numpy())
    if not finite.all():
        bad_cols = [c for c, ok in zip(cols, finite.all(axis=0)) if not ok]
        raise Refused('features_non_finite', '%d row(s), columns %s'
                      % (int((~finite.all(axis=1)).sum()), bad_cols[:5]))

    # Same test, same tolerance, as new_train_session.feature_columns.
    std = block.std(axis=0, ddof=0)
    constant = [c for c in cols if not std[c] > TR.CONST_STD_TOL]
    if constant:
        raise Refused('features_constant', '%d constant for this user, e.g. %s'
                      % (len(constant), constant))


def availability_totals(envelope_path):
    """Summed payload_canonicalizer availability over every session in the
    envelope: how many keystrokes per field tag, visits per screen tag,
    gestures per type, keyboard touches ... this user's app actually produced."""
    totals = {}
    for s in BC.iter_raw_sessions(envelope_path):
        for k, v in (CANON.canonicalize_session(s).get('availability')
                     or {}).items():
            totals[k] = totals.get(k, 0) + int(v)
    return totals


def _measurable_flag_reason(df, col):
    """The family's own *_measurable flag says 'never measurable' for every
    training row. Looked up by trimming the column name back one word at a
    time: kg_fs_acct_name_roll_std -> kg_fs_acct_name_measurable."""
    parts = col.split('_')
    for i in range(len(parts) - 1, 0, -1):
        flag = '_'.join(parts[:i]) + '_measurable'
        if flag != col and flag in df.columns:
            try:
                vals = df[flag].astype(float).to_numpy()
            except (TypeError, ValueError):
                return None
            if np.isfinite(vals).all() and (vals == 0).all():
                return '%s is 0 in every training session' % flag
            return None
    return None


# Census capability flags: the device itself does not report these inputs.
CAPABILITY_FLAGS = (
    ('cap_touch_pressure', ('touch_press_', 'touch_dpress_', 'touch_cap_pressure')),
    ('cap_touch_size', ('touch_size_', 'touch_dsize_', 'touch_major_',
                        'touch_toolmajor_', 'tgeo_', 'touch_cap_size')),
)


def _capability_reason(df, col):
    for flag, prefixes in CAPABILITY_FLAGS:
        if col.startswith(prefixes) and flag in df.columns:
            vals = pd.to_numeric(df[flag], errors='coerce').to_numpy()
            if np.isfinite(vals).all() and (vals == 0).all():
                return '%s is 0 in every training session' % flag
    return None


def split_unavailable(df, cols, totals):
    """(kept columns, {dropped column: reason}).

    Only a column that is CONSTANT for this user and has a structural reason
    is dropped. A constant column without one stays in `kept`, so
    _gate_training_frame refuses it as features_constant - a real fault must
    never be explained away."""
    present = [c for c in cols if c in df.columns]
    if not present:
        return list(cols), {}
    try:
        std = df[present].astype(float).std(axis=0, ddof=0)
    except (TypeError, ValueError):
        return list(cols), {}
    dropped = {}
    for c in present:
        if std[c] > TR.CONST_STD_TOL:
            continue
        reason = CANON.unavailable_reason(c, totals) \
            or _measurable_flag_reason(df, c) \
            or _capability_reason(df, c)
        if reason:
            dropped[c] = reason
    return [c for c in cols if c not in dropped], dropped


def _gate_calibration(model):
    """Gate 6 - the threshold really was calibrated, on real spread."""
    loo = model.loo_scores
    if loo is None or len(loo) < MIN_LOO_SCORES:
        raise Refused('uncalibrated', 'loo_scores=%s'
                      % (None if loo is None else len(loo)))
    loo = np.asarray(loo, dtype=float)
    if not np.isfinite(loo).all():
        raise Refused('scores_non_finite')
    if not math.isfinite(float(model.threshold)):
        raise Refused('threshold_non_finite')
    if not float(np.ptp(loo)) > LOO_PTP_TOL:
        raise Refused('scores_degenerate', 'ptp(loo_scores)=%r' % float(np.ptp(loo)))


def _holdout(model, test_csv, cols):
    """Step 8: FRR on the held-out genuine sessions. Recorded, never gated on."""
    out = {'holdout_n': 0, 'holdout_frr': None, 'holdout_refused': 0}
    if not os.path.exists(test_csv):
        return out
    test = pd.read_csv(test_csv, low_memory=False)
    if test.empty or 'test_type' not in test.columns:
        return out
    held = test[test['test_type'].astype(str).str.lower() == 'genuine']
    if held.empty or any(c not in held.columns for c in cols):
        return out
    finite = np.isfinite(held[cols].astype(float).to_numpy()).all(axis=1)
    # Serving refuses a non-finite row (bundle_loader.vectorise), so it would
    # never get a verdict; count it apart instead of scoring a zero-filled one.
    out['holdout_refused'] = int((~finite).sum())
    scored = held[finite]
    if not scored.empty:
        scores = model.score(model._matrix(scored))
        out['holdout_n'] = int(len(scores))
        out['holdout_frr'] = float(np.mean(scores < model.threshold))
    return out


# =============================================================================
#  steps 4-11
# =============================================================================

def build_bundle(user_id, envelope_path, stage_dir, profile_id=None,
                 census_source='', counts=None):
    """
    Steps 4-11 on one envelope file. Everything is written under stage_dir.

    Returns a dict with the staged bundle / templates paths and what was
    recorded. Raises Refused when the gate says no; any other exception is a
    failure of the run, not a verdict on the user.
    """
    if not valid_user_id(user_id):
        raise Refused('bad_user_id')
    profile = active_profile()
    cols, selection, selection_sha = check_selection(profile)
    counts = dict(counts or {})
    logger.info('%s: building with selection %r (%s, %d features)%s', user_id,
                profile['name'], profile['file'], len(cols),
                ' [experimental]' if profile['experimental'] else '')

    tpl_dir = os.path.join(stage_dir, 'templates')
    feat_dir = os.path.join(stage_dir, 'features')
    model_dir = os.path.join(stage_dir, 'models')

    # ---- 4. DTW templates ---------------------------------------------------
    # n_jobs=1 is mandatory: the module default (ADAPID_N_JOBS=-1) takes every
    # core and starves the gunicorn workers scoring next to it.
    print('[BUILD] %s: step 4/11 building DTW templates...' % user_id, flush=True)
    tpl_path = DTW.build_for_user(envelope_path, out_dir=tpl_dir,
                                  verbose=False, n_jobs=1)
    print('[BUILD] %s: DTW templates -> %s' % (user_id, tpl_path), flush=True)
    if tpl_path is None:
        raise Refused('too_few_sessions',
                      'fewer than %d training sessions after sanitizer and '
                      'holdout; no templates' % DTW.MIN_TRAIN_SERIES)
    expected_tpl = os.path.join(tpl_dir, '%s_dtw_templates.pkl' % user_id)
    if os.path.abspath(tpl_path) != os.path.abspath(expected_tpl):
        raise Refused('user_id_mismatch', 'envelope names a different user: %s'
                      % os.path.basename(tpl_path))

    # ---- 5. features --------------------------------------------------------
    # Explicit dirs always: the modules default from ADAPID_* env vars. And no
    # KF.configure(): research main() calls it, serving does not, and serving
    # already reproduces the research CSVs.
    print('[BUILD] %s: step 5/11 extracting features...' % user_id, flush=True)
    result = V2.SessionPipelineV2(envelope_path, template_dir=tpl_dir,
                                  verbose=False).run(out_dir=feat_dir)
    if not result:
        raise Refused('no_training_sessions')
    train_csv, test_csv = result
    print('[BUILD] %s: features -> train=%s test=%s' % (user_id, train_csv,
          test_csv), flush=True)

    # ---- 6. census ----------------------------------------------------------
    # What package_ml_bundle.py:211 did, over the same unmutated file the
    # pipeline read, so it equals the census the features were built under.
    print('[BUILD] %s: step 6/11 building census...' % user_id, flush=True)
    census = BC.build_census(BC.iter_raw_sessions(envelope_path), user_id)

    # ---- 7. train (gates 3-6) -----------------------------------------------
    df = pd.read_csv(train_csv, low_memory=False)   # as SessionOCSVM.load reads it

    # ---- 7a. features this user's app cannot produce ------------------------
    # `cols` is the pinned selection; `train_cols` is what this user's model is
    # trained and served on. They differ only by features whose input never
    # occurs in this user's sessions (see MIN_AVAILABLE_FRACTION).
    totals = availability_totals(envelope_path)
    train_cols, unavailable = split_unavailable(df, cols, totals)
    if unavailable:
        print('[BUILD] %s: %d selected feature(s) unavailable for this app, '
              'dropped: %s' % (user_id, len(unavailable),
                               sorted(unavailable)), flush=True)
    if len(train_cols) < MIN_AVAILABLE_FRACTION * len(cols):
        raise Refused('too_few_available_features',
                      '%d of %d selected features can be built from this '
                      "user's sessions, e.g. %s"
                      % (len(train_cols), len(cols),
                         dict(list(unavailable.items())[:3])))
    _gate_training_frame(df, train_cols)

    print('[BUILD] %s: step 7/11 fitting One-Class SVM on %d row(s), %d feature(s)...'
          % (user_id, len(df), len(train_cols)), flush=True)
    model = TR.SessionOCSVM(user_id)
    model.verbose = False
    model.feature_columns, model.drop_report = TR.feature_columns(
        df, feature_list=train_cols)
    if list(model.feature_columns) != train_cols:
        raise Refused('features_changed', 'feature_columns() did not keep all %d'
                      % len(train_cols))
    X = model._matrix(df)
    model.fit(X, calibrate_frr=CALIBRATE_FRR, calibrate_method=CALIBRATE_METHOD)
    _gate_calibration(model)
    print('[BUILD] %s: SVM fit done, threshold=%s' % (user_id, model.threshold),
          flush=True)

    # ---- 8. holdout FRR (record only) ---------------------------------------
    holdout = _holdout(model, test_csv, train_cols)

    # ---- 10. assemble -------------------------------------------------------
    templates = joblib.load(tpl_path)
    n_in_file = int(census.get('n_sessions', 0)) + int(census.get('n_sessions_skipped', 0))
    sc = templates.get('session_counts') or {}
    n_after_sanitizer = sum(int(sc.get(k) or 0)
                            for k in ('train', 'test_genuine', 'test_impostor'))

    needs, hits = PKG.needs_census_for(train_cols)
    # Certification is tied to the PINNED selection (the full list); the
    # features actually trained on, and the ones left out and why, are
    # recorded beside it.
    how, flags = PKG.match_selection(selection, cols, user_id)
    # An experimental profile may train from a non-deployable selection; its
    # provenance then says so, and the bundle is served uncertified.
    if how != 'global_exact' or (flags['deployable'] is not True
                                 and not profile['experimental']):
        raise Refused('selection_unmatched', 'match=%s deployable=%r'
                      % (how, flags['deployable']))

    now = _dt.datetime.now().isoformat(timespec='seconds')
    print('[BUILD] %s: step 10/11 saving bundle to %s ...' % (user_id, model_dir),
          flush=True)
    bundle_path = model.save(model_dir)
    raw = joblib.load(bundle_path)
    # Key set mirrors package_ml_bundle.package_user, with values true of THIS
    # build rather than copied from research.
    warning = flags['warning']
    if unavailable:
        note = ('%d of %d selected features cannot be built from this '
                "user's app and were left out (provenance."
                'features_unavailable)' % (len(unavailable), len(cols)))
        warning = '%s; %s' % (warning, note) if warning else note
    raw['provenance'] = {
        'viable': flags['viable'],
        'deployable': flags['deployable'],
        'probe': flags['probe'],
        'warning': warning,
        'selection_file': profile['file'],
        'selection_profile': profile['name'],
        'selection_match': how,
        'selection_sha256': selection_sha,
        # the columns this model was trained on and is served with
        'feature_set_sha256': PKG.feature_set_sha256(train_cols),
        'n_features': len(train_cols),
        # the pinned selection, and what was left out of it and why
        'selection_feature_set_sha256': PKG.feature_set_sha256(cols),
        'n_features_selected': len(cols),
        'features_unavailable': dict(sorted(unavailable.items())),
        'availability': totals,
        'canonicalizer_version': CANON.CANON_VERSION,
        'trainer': 'new_train_session.py',
        'trainer_sha256': trainer_sha256(),
        # Input is genuine-only by construction (is_eligible), and no impostor
        # session is read at any point.
        'contaminated': False,
        'source_models_dir': None,          # built in a staging dir, now gone
        'built_at': now,
        'sklearn_version': sklearn.__version__,
        'extractor': 'v2',
        'needs_census': needs,
        'census_features': sorted(hits)[:20],
        'packaged_by': 'enrollment_service.py',
        'calibrate_frr': CALIBRATE_FRR,
        'profile_id': profile_id,
        'enrolment': {
            'n_fetched': counts.get('n_fetched'),
            'n_eligible': counts.get('n_eligible', n_in_file),
            'n_unreadable': counts.get('n_unreadable', 0),
            'n_train': int(len(df)),
            'n_holdout': int(sc.get('test_genuine') or 0),
            'n_excluded_sanitizer': n_in_file - n_after_sanitizer,
            'holdout_frr': holdout['holdout_frr'],
            'holdout_n': holdout['holdout_n'],
            'holdout_refused': holdout['holdout_refused'],
            'target_frr': CALIBRATE_FRR,
        },
    }
    raw['frozen_state'] = {
        'clean_census': census,
        'census_source': census_source,
        'census_n_sessions': census.get('n_sessions'),
        'census_built_at': now,
    }
    joblib.dump(raw, bundle_path)

    # ---- 11. validate with the real serving loader (gate 7) -----------------
    print('[BUILD] %s: step 11/11 validating bundle with the serving loader...'
          % user_id, flush=True)
    try:
        bundle, _ = BundleStore(model_dir, tpl_dir).get(user_id)
    except (ArtifactError, ExtractionError, OSError) as error:
        raise Refused('bundle_invalid', str(error)[:300])
    if not math.isfinite(bundle.threshold) \
            or (bundle.uncertified and not profile['experimental']):
        raise Refused('bundle_invalid', 'threshold=%r uncertified=%r'
                      % (bundle.threshold, bundle.uncertified))
    print('[BUILD] %s: bundle validated OK, threshold=%s' % (user_id,
          bundle.threshold), flush=True)

    return {
        'user_id': user_id,
        'bundle_path': bundle_path,
        'templates_path': tpl_path,
        'features_unavailable': dict(unavailable),
        'train_csv': train_csv,
        'test_csv': test_csv,
        'threshold': float(model.threshold),
        'built_at': now,
        'census': census,
        'enrolment': raw['provenance']['enrolment'],
        'model': model,
    }


# =============================================================================
#  step 12 - publish, never overwriting a bundle
# =============================================================================

def _fsync_file(path):
    with open(path, 'rb+') as fh:          # Windows refuses fsync on read-only
        os.fsync(fh.fileno())


def _fsync_dir(path):
    if os.name != 'posix':                # Windows cannot open a directory
        return
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def bundle_file(models_dir, user_id):
    return os.path.join(models_dir, '%s_ocsvm.joblib' % user_id)


def templates_file(templates_dir, user_id):
    return os.path.join(templates_dir, '%s_dtw_templates.pkl' % user_id)


def publish(user_id, staged_bundle, staged_templates, models_dir, templates_dir):
    """
    'published', or 'exists' when the user already has a bundle.

    BundleStore caches a loaded bundle forever, so an overwrite would never be
    seen by a running worker - and a first enrolment is picked up on the next
    request because misses are never cached. Hence templates first, bundle
    LAST: the bundle is the commit point, and until it exists nothing reads the
    templates. Staging must be on the same filesystem (os.replace).
    """
    dst_bundle = bundle_file(models_dir, user_id)
    if os.path.exists(dst_bundle):
        return 'exists'
    dst_templates = templates_file(templates_dir, user_id)
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(templates_dir, exist_ok=True)

    _fsync_file(staged_templates)
    _fsync_file(staged_bundle)
    os.replace(staged_templates, dst_templates)
    _fsync_dir(templates_dir)
    os.replace(staged_bundle, dst_bundle)
    _fsync_dir(models_dir)
    return 'published'


# =============================================================================
#  the trainer's entry point: steps 1-13 for one user
# =============================================================================

def enrol(user_id, profile_id=None, job_id=None, fetch=None):
    """
    Fetch, filter, build, validate, publish. The staging dir always goes.

    Returns {'user_id', 'published': 'published'|'exists', ...}. Raises
    Refused (the gate), Retryable (transient), or anything else (a bug or bad
    data from NAV); in every case nothing has been published.
    """
    if not valid_user_id(user_id):
        raise Refused('bad_user_id')
    check_selection()                             # gate 1, before any fetch
    mdir, tdir = models_dir(), templates_dir()
    if os.path.exists(bundle_file(mdir, user_id)):
        return {'user_id': user_id, 'published': 'exists'}

    print('[ENROL] %s: starting NavFetch base_url=%s' % (user_id, nav_base_url()),
          flush=True)
    fetch = fetch or NavFetch(user_id)
    # Same filesystem as mdir/tdir (/data), so publish's os.replace is atomic.
    stage = os.path.join(jobs_dir(), 'staging',
                         job_id or '%s-%d-%d' % (user_id, int(time.time()), os.getpid()))
    os.makedirs(stage)                            # fresh per job, never reused
    try:
        # ---- 1-3. fetch, filter, write ----------------------------------
        envelope = os.path.join(stage, ENVELOPE_NAME)
        writer = EnvelopeWriter(envelope)
        n_unreadable = 0
        try:
            for session in fetch.sessions():
                # print(f"the data is {session}")
                # with open("session.json", "w", encoding="utf-8") as f:
                #     json.dump(session, f, indent=4, default=str)
                # break
                if not is_eligible(session, user_id):
                    continue
                if is_unreadable(session):
                    n_unreadable += 1
                    continue
                writer.add(session)
        except BaseException:
            writer.abort()
            raise
        n = writer.close(user_id, fetch.profile)

        if profile_id is not None and str(fetch.profile.get('id')) != str(profile_id):
            raise Refused('profile_mismatch', 'NAV asked for profile %s, the '
                          'sessions belong to %s' % (profile_id, fetch.profile.get('id')))
        if n == 0:
            raise Refused('no_eligible_sessions')
        logger.info('%s: fetched %d of %d in %d page(s), %d eligible, %d unreadable',
                    user_id, fetch.n_collected, fetch.total, fetch.pages, n,
                    n_unreadable)
        print('[ENROL] %s: fetched %d of %d session(s) in %d page(s) -> '
              '%d eligible, %d unreadable' % (user_id, fetch.n_collected,
              fetch.total, fetch.pages, n, n_unreadable), flush=True)

        census_source = ('GET %s/behavioral/sessions/%s fetched_at=%s n=%d '
                         'total=%d page=%d' % (fetch.base_url, user_id,
                                               fetch.fetched_at, n, fetch.total,
                                               PAGE_SIZE))
        # ---- 4-11 -------------------------------------------------------
        built = build_bundle(
            user_id, envelope, stage, profile_id=fetch.profile.get('id'),
            census_source=census_source,
            counts={'n_fetched': fetch.n_collected,
                    'n_eligible': n + n_unreadable,   # what NAV counted
                    'n_unreadable': n_unreadable})
        # ---- 12 ---------------------------------------------------------
        published = publish(user_id, built['bundle_path'],
                            built['templates_path'], mdir, tdir)
        return {'user_id': user_id, 'published': published,
                'built_at': built['built_at'], 'threshold': built['threshold'],
                'enrolment': built['enrolment']}
    finally:
        # ---- 13 ---------------------------------------------------------
        shutil.rmtree(stage, ignore_errors=True)
