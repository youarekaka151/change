"""Startup preconditions for the ADAPID ML prediction API.

Every check here answers a failure that ALREADY HAPPENED in this project and was
invisible when it did. The rule is the same in each case: refuse to start rather
than serve a number nobody can trust.

    from boot_checks import run_boot_checks
    report = run_boot_checks()          # raises BootCheckError on any failure

WHAT IS CHECKED, AND WHICH MEASURED FAILURE IT ANSWERS
-------------------------------------------------------
1. VENDOR IMPORT.  vendor/ is a verbatim copy of the research pipeline's
   feature closure. If it cannot be imported there is no feature code at all,
   so that is caught here rather than at the first request.

2. NON-OPTIONAL "OPTIONAL" DEPENDENCIES.  new_feature_creation_session imports
   pywt behind try/except and sets _HAVE_PYWT; v2 does the same for allantools;
   keystroke_fields is imported as KF or left None. Upstream that is correct -
   a research run should lose columns rather than die. Here it is wrong:
   rev4's 50 features include acc_mag_wav_A_energy, gyro_x_wav_D1_std and
   acc_z_wav_A_energy, all of which are pywt wavelet features. Without pywt
   they would silently become zeros and be z-scored into a large constant
   offset. That is Gap 7, and it is the mechanism behind the constant -1.89
   verdict the old service returned for every session.

3. FEATURE_EXCLUDE_* ENVIRONMENT.  new_feature_registry._resolve_exclusions()
   runs at IMPORT time and raises ValueError on an unknown group, so a stray
   env var on the host turns into a crash at first request rather than at boot.
   It can also silently change which columns the registry considers live.
   Neither belongs in a scoring service; the registry must behave identically
   here and in the research repo.

4. THIRD-PARTY VERSION AGREEMENT.  requirements.txt pins the scientific stack
   the closure was exercised against. If the live stack disagrees, the pickled
   estimators may unpickle with an InconsistentVersionWarning (Gap 10).
   Mismatch is a hard failure for scikit-learn (it owns the pickles) and a
   warning for the rest.
"""

from __future__ import annotations

import importlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REQUIREMENTS = os.path.join(os.path.dirname(HERE), 'requirements.txt')

# Env vars new_feature_registry reads at import time. See check 3.
FORBIDDEN_ENV = (
    'FEATURE_EXCLUDE_GROUPS',
    'FEATURE_EXCLUDE_FAMILIES',
    'FEATURE_KEEP_FAMILIES',
)

# The stack that decides a score. Flask and gunicorn cannot move a number, so
# they are pinned in requirements.txt but not checked here.
CHECKED_PACKAGES = ('numpy', 'pandas', 'scipy', 'scikit-learn', 'tslearn',
                    'joblib', 'PyWavelets', 'allantools')

# A version disagreement on this package invalidates the pickled model and
# scaler themselves, not merely the feature values.
HARD_VERSION_PACKAGES = ('scikit-learn',)

_IMPORT_NAME = {
    'scikit-learn': 'sklearn',
    'PyWavelets': 'pywt',
}


class BootCheckError(RuntimeError):
    """A startup precondition failed. The service must not serve traffic."""


def _version_of(pip_name):
    mod_name = _IMPORT_NAME.get(pip_name, pip_name)
    try:
        mod = importlib.import_module(mod_name)
    except ImportError:
        return None
    version = getattr(mod, '__version__', None)
    if version:
        return version
    try:                                    # Flask/Werkzeug dropped __version__
        from importlib.metadata import version as _md_version
        return _md_version(pip_name)
    except Exception:                       # noqa: BLE001
        return 'unknown'


# --------------------------------------------------------------- the checks

def _check_env(report, problems):
    """3. No FEATURE_EXCLUDE_* may be set."""
    found = {k: os.environ[k] for k in FORBIDDEN_ENV if k in os.environ}
    report['env'] = {'forbidden_set': found}
    for key, value in found.items():
        problems.append(
            "%s is set (%r). new_feature_registry reads it at import and it "
            "changes which columns are considered live; unset it." % (key, value))


def _check_vendor(report, problems):
    """1. vendor/ imports."""
    if HERE not in sys.path:
        sys.path.insert(0, HERE)
    vendor_dir = os.path.join(HERE, 'vendor')
    try:
        import vendor                        # noqa: F401  puts vendor/ on sys.path
    except Exception as error:               # noqa: BLE001
        report['vendor'] = {'ok': False, 'error': str(error)}
        problems.append('vendor/ is not importable: %s' % error)
        return False

    report['vendor'] = {
        'ok': True,
        'n_files': len([f for f in os.listdir(vendor_dir)
                        if f.endswith('.py') and f != '__init__.py']),
    }
    return True


def _check_optional_deps(report, problems):
    """2. pywt, allantools and keystroke_fields are mandatory here."""
    state = {}
    try:
        import new_feature_creation_session as V1
        import new_feature_creation_session_v2 as V2
    except Exception as error:               # noqa: BLE001
        report['feature_modules'] = {'ok': False, 'error': str(error)}
        problems.append('cannot import the vendored extractor: %s' % error)
        return

    state['_HAVE_PYWT'] = bool(getattr(V1, '_HAVE_PYWT', False))
    state['_HAVE_ALLAN'] = bool(getattr(V2, '_HAVE_ALLAN', False))
    state['KF'] = getattr(V1, 'KF', None) is not None
    report['feature_modules'] = dict(state, ok=all(state.values()))

    if not state['_HAVE_PYWT']:
        problems.append(
            'pywt is not importable, so new_feature_creation_session set '
            '_HAVE_PYWT=False. Every wav_* feature would silently become 0.0 '
            '(rev4 alone selects three of them). Install PyWavelets.')
    if not state['_HAVE_ALLAN']:
        problems.append(
            'allantools is not importable, so new_feature_creation_session_v2 '
            'set _HAVE_ALLAN=False and the adev_* family would silently be '
            'zero-filled. Install allantools.')
    if not state['KF']:
        problems.append(
            'keystroke_fields did not import (KF is None), so the per-field '
            'keystroke columns would be missing. It is vendored - this means '
            'an import error inside it, not an absent file.')


def _pinned_versions():
    """{package: version} for every `name==version` line in requirements.txt."""
    pins = {}
    try:
        with open(REQUIREMENTS, 'r', encoding='utf-8') as fh:
            lines = fh.readlines()
    except OSError:
        return pins
    for line in lines:
        line = line.split('#', 1)[0].strip()
        name, sep, version = line.partition('==')
        if sep and name.strip() in CHECKED_PACKAGES:
            pins[name.strip()] = version.strip()
    return pins


def _check_versions(report, problems):
    """4. The live scientific stack matches what requirements.txt pins."""
    pinned = _pinned_versions()
    live = {name: _version_of(name) for name in pinned}
    report['versions'] = {'pinned': pinned, 'live': live, 'mismatch': {}}

    for name, want in sorted(pinned.items()):
        got = live.get(name)
        if got == want:
            continue
        report['versions']['mismatch'][name] = {'pinned': want, 'live': got}
        message = ('%s is %s but requirements.txt pins %s' % (name, got, want))
        if name in HARD_VERSION_PACKAGES:
            problems.append(
                message + '. The bundled estimators were pickled by that '
                'version; unpickling across versions is unsupported.')
        else:
            report.setdefault('warnings', []).append(message)


# ------------------------------------------------------------------ driver

def run_boot_checks(strict=True):
    """
    Run every precondition. Returns a report dict.

    Raises BootCheckError when `strict` and anything failed. The caller is
    expected to let that propagate: a service that cannot verify its own feature
    code has nothing trustworthy to say about a session.
    """
    report = {}
    problems = []

    _check_env(report, problems)
    if _check_vendor(report, problems):
        _check_optional_deps(report, problems)
        _check_versions(report, problems)

    report['problems'] = problems
    report['ok'] = not problems

    if problems and strict:
        raise BootCheckError(
            'ML API boot checks failed (%d problem(s)):\n  - %s'
            % (len(problems), '\n  - '.join(problems)))
    return report


def format_report(report):
    """One short block for the startup log."""
    lines = []
    vendor = report.get('vendor') or {}
    if vendor.get('ok'):
        lines.append('vendor      : %d files' % vendor.get('n_files', 0))
    else:
        lines.append('vendor      : FAILED - %s' % vendor.get('error'))

    modules = report.get('feature_modules') or {}
    if modules:
        lines.append('extractor   : pywt=%s allantools=%s keystroke_fields=%s'
                     % (modules.get('_HAVE_PYWT'), modules.get('_HAVE_ALLAN'),
                        modules.get('KF')))

    versions = report.get('versions') or {}
    mismatch = versions.get('mismatch') or {}
    lines.append('versions    : %d pinned, %d mismatched'
                 % (len(versions.get('pinned') or {}), len(mismatch)))

    forbidden = (report.get('env') or {}).get('forbidden_set') or {}
    lines.append('environment : %s'
                 % ('clean' if not forbidden
                    else 'FEATURE_EXCLUDE_* SET: %s' % sorted(forbidden)))

    for warning in report.get('warnings') or []:
        lines.append('warning     : %s' % warning)
    return '\n'.join(lines)


if __name__ == '__main__':
    try:
        rep = run_boot_checks(strict=True)
    except BootCheckError as err:
        print(err)
        sys.exit(1)
    print(format_report(rep))
    print('\nBOOT CHECKS: OK')
