"""Session -> feature dict, using the vendored research-pipeline closure.

This module owns NO feature logic. It is a call sequence. Every number it
returns is computed by code in vendor/, which is a verbatim copy of the
research pipeline (see PHASE2_DESIGN.md Part 2).
That is the whole point: the previous service carried its own 2,420-line
reimplementation, it drifted, and it ended up computing nothing at all
(COORDINATION_AUDIT.md Part 0).

THE CHAIN, AND WHY EACH STEP IS THERE
-------------------------------------
PHASE2_DESIGN.md Sec 3.8 settles what a single-session service needs:

    1. behavior_cleaner.clean_session(raw, census)      <- ALWAYS. see below
    2. new_adapid_schema.SessionView(raw, align_hz=50)
    3. view.recompute_caps(census)                      <- with the same census
    4. new_sensor_sanitizer.sanitize_view(view)         <- ALWAYS
    5. SessionFeatureExtractorV2().extract(view, templates, session_idx=None)

Step 4 is not optional. 27.6% of the training corpus is `san_verdict ==
'REPAIRED'`, and on such a session it moves 16 of the 272 features any bundle on
disk selects; on one measured surya session it took rev4's agreement with the
stored CSV row from 48/50 to 50/50. Phase 1 nearly scoped it out because the
session it happened to test came from a handset that is 99.3% clean.

STEP 1 IS ALSO NOT OPTIONAL - CORRECTING PHASE2_DESIGN.md Sec 3.8
-----------------------------------------------------------------
That section gated step 1 on `provenance.needs_census`, on the grounds that the
census only reaches place_/kb_/kbres_ columns. The acceptance gate disproved it
immediately: three rev4 users failed feature parity on `key_dwell_p5` and
`touch_dur_p5`, with relative errors up to 0.91, while the one bundle that DID
run the cleaner passed 50/50.

The reasoning error is now clear. `clean_session` has two halves
(behavior_cleaner.py:525-544):

    pass A  _dedupe_keys, _collapse_key_repeats, _fix_key_intervals,
            _dedupe_touches, _fix_touch_durations   <- NO census argument
    pass B  _resolve_keyboard_taps, _mark_dead_air  <- census-driven

Only pass B needs the census. Pass A is census-independent, unconditional, and
repairs key and touch events directly - so it moves key_* and touch_* features,
of which rev4 selects twelve. The Sec 3.5 measurement attributed the whole diff
to "the census" because the single session it used happened to have a no-op
pass A. Measured across the corpus instead: 901 of 1,241 sessions (72.6%) carry
at least one pass-A repair.

So the cleaner runs unconditionally, which is what Sec 3.6 recommended anyway
("ship the census unconditionally... the detection rule's job is then to warn").
`needs_census` survives as a diagnostic: it says whether this bundle's features
depend on pass B specifically, and is surfaced rather than used as a gate.

Step 5 always passes session_idx=None. That is the documented, correct value for
any session outside the template's training set - which a live request always is
(new_build_dtw_templates.compute_dtw_features, "None is always safe").
"""

from __future__ import annotations

import copy
import logging
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import vendor                                   # noqa: E402,F401  puts vendor/ on sys.path

import behavior_cleaner as BC                   # noqa: E402
import new_adapid_schema as SCH                 # noqa: E402
import new_sensor_sanitizer as SAN              # noqa: E402
import new_feature_creation_session_v2 as V2    # noqa: E402
import narrowing as NARROW                      # noqa: E402  Change 3

logger = logging.getLogger(__name__)

# The extractor is stateless across sessions; building it once avoids rebuilding
# its key tables per request.
_EXTRACTOR = V2.SessionFeatureExtractorV2()

# Change 3: inside the selected families, compute only what the model's columns
# read. Off unless ML_EXTRACT_NARROW=1. The wrappers are installed once, here,
# after V2 (which installs the 10-key _agg_block that gets wrapped); they stay
# inert until _extract_row sets NARROW.READ_KEYS for one extraction.
EXTRACT_NARROW = (os.getenv('ML_EXTRACT_NARROW') or '').strip() == '1'
if EXTRACT_NARROW:
    NARROW.install()

ALIGN_HZ = SCH.ALIGN_HZ_DEFAULT                 # 50.0

# ---- extract only the families that produce a model's columns ---------------
# Same family order as SessionFeatureExtractor.extract (v1) and
# SessionFeatureExtractorV2.V2_FAMILIES, so a key emitted by two families ends
# up with the same value as in the full extraction.
_V1_FAMILIES = ('context', 'navigation', 'touch', 'touch_paths', 'keystrokes',
                'sensor_stats', 'sensor_spectral', 'sensor_complexity',
                'derived_motion', 'orientation', 'correlations', 'tap_locked',
                'touch_motion_coupling', 'per_screen', 'cognitive', 'placement',
                'key_locked', 'stage2', 'stage3')

# columns tuple -> ((v1 families...), (v2 families...), read_keys, tap_need), or
# None when some column does not come from a family (then the full extraction
# is always used). read_keys / tap_need are only used when EXTRACT_NARROW.
_FAMILY_PLAN = {}


def _learn_plan(cview, columns):
    """Run every family once and record which ones produce `columns`.

    Runs with the Change-3 gates inactive (READ_KEYS is not set yet), so every
    family emits its full key set and ownership is learned exactly as before.
    """
    owner = {}
    for name in _V1_FAMILIES:
        for key in getattr(_EXTRACTOR, 'extract_' + name)(cview):
            owner.setdefault(key, ('v1', name))
    for name in _EXTRACTOR.V2_FAMILIES:
        for key in getattr(_EXTRACTOR, 'extract_' + name)(cview):
            owner[key] = ('v2', name)          # v2 row.update() wins, as in extract()
    if any(c not in owner for c in columns):
        return None
    needed = {owner[c] for c in columns}
    tap_cols = [c for c in columns if owner[c] == ('v1', 'tap_locked')]
    return (tuple(n for n in _V1_FAMILIES if ('v1', n) in needed),
            tuple(n for n in _EXTRACTOR.V2_FAMILIES if ('v2', n) in needed),
            NARROW.read_keys_for(columns),
            NARROW.tap_need_for(tap_cols))


def _extract_row(view, templates, columns):
    """
    The model's columns only, identical to the full extraction (verified on 36
    real sessions: 50/50 features bit-identical). Falls back to the full
    extraction when a column is not covered, a family fails, or no column
    list is given - so a result is never weaker than before.
    """
    if not columns:
        return _EXTRACTOR.extract(view, templates, None)
    key = tuple(columns)
    cview = V2.CleanView(view)
    try:
        if key not in _FAMILY_PLAN:
            _FAMILY_PLAN[key] = _learn_plan(cview, columns)
        plan = _FAMILY_PLAN[key]
        if plan is None:
            return _EXTRACTOR.extract(view, templates, None)
        v1_names, v2_names, read_keys, tap_need = plan
        # Change 3: gated helpers + narrowed tap_locked, for THIS extraction only
        # (a context variable, so per request / greenlet). Reset before anything
        # else runs, including the full-extraction fallbacks below.
        token = NARROW.READ_KEYS.set(read_keys) if EXTRACT_NARROW else None
        try:
            row = {}
            for name in v1_names:
                if name == 'tap_locked' and token is not None and tap_need:
                    row.update(NARROW.tap_locked_narrow(_EXTRACTOR, cview, tap_need))
                else:
                    row.update(getattr(_EXTRACTOR, 'extract_' + name)(cview))
            for name in v2_names:
                row.update(getattr(_EXTRACTOR, 'extract_' + name)(cview))
        finally:
            if token is not None:
                NARROW.READ_KEYS.reset(token)
        _EXTRACTOR._correct_navigation(row, cview)
        _EXTRACTOR._drop_dead_and_leaking(row)
    except Exception:                                   # noqa: BLE001
        logger.warning('selected-family extraction failed, using full extraction',
                       exc_info=True)
        return _EXTRACTOR.extract(view, templates, None)
    if any(c not in row for c in columns):
        return _EXTRACTOR.extract(view, templates, None)
    row['feat_errors'] = ''
    row['feat_n_errors'] = 0.0
    return row


class ExtractionError(RuntimeError):
    """The session could not be turned into a trustworthy feature vector."""


# Mirrors Payz_nav-backend_new/app/database.py SENSOR_TYPES / SENSOR_ALIASES.
_SENSOR_TYPES = frozenset((
    'accelerometer', 'gyroscope', 'magnetometer', 'linear_acceleration',
    'gravity', 'rotation_vector', 'game_rotation_vector', 'proximity', 'light',
    'pressure', 'step_counter', 'heart_rate', 'pose_6dof',
    'linear_accelerometer'))
_SENSOR_ALIASES = {'linear_accelerometer': 'linear_acceleration'}
_SAMPLE_FIELDS = ('x', 'y', 'z', 'w', 'heading_accuracy_rad', 'values',
                  'n_values', 'req_hz', 'screen', 'accuracy')


def _first(d, *names):
    for n in names:
        v = d.get(n)
        if v is not None:
            return v
    return None


def normalize_upload_shape(raw):
    """
    Rewrite, in place, a session in the app's UPLOAD shape into the shape
    BehavioralData.get_session_by_id() returns - the only shape the vendored
    pipeline was trained on. Reproduces the backend's write+read round trip
    (behavioral_data.py _insert_sensor_samples/_get_sensor_samples,
    _touch_row/_path_rows, _get_touch_events) for every field the pipeline
    reads. A backend-read session is left unchanged.

    behavior_cleaner indexes sensor_samples by sensor name, so a flat list
    crashes it. Touch/path `size` does not crash, but the pipeline reads only
    down_size/point_size, so on a handset that reports real touch size every
    touch-size feature would silently go empty.
    """
    ss = raw.get('sensor_samples')
    if isinstance(ss, list):
        grouped = {}
        for s in ss:
            if not isinstance(s, dict):
                continue
            name = str(s.get('sensor_type') or s.get('sensor') or '').strip().lower()
            name = _SENSOR_ALIASES.get(name, name)
            if name not in _SENSOR_TYPES:
                continue
            t = _first(s, 't', 'ts', 'timestamp')
            if t is None:
                continue
            row = {'t': int(t)}
            for f in _SAMPLE_FIELDS:
                row[f] = s.get(f)
            grouped.setdefault(name, []).append(row)
        for series in grouped.values():
            series.sort(key=lambda r: r['t'])
        raw['sensor_samples'] = grouped

    touches = raw.get('touch_events')
    if isinstance(touches, list):
        for t in touches:
            if not isinstance(t, dict):
                continue
            if t.get('down_size') is None and t.get('size') is not None:
                t['down_size'] = t['size']
            for i, p in enumerate(t.get('path') or []):
                if not isinstance(p, dict):
                    continue
                if p.get('point_size') is None and p.get('size') is not None:
                    p['point_size'] = p['size']
                if p.get('seq') is None:
                    p['seq'] = i
        touches.sort(key=lambda t: (t.get('touch_down_ts') is None,
                                    t.get('touch_down_ts') or 0))


def extractor_identity():
    """What this module will run, for the startup log and /nav/ai/info."""
    return {
        'extractor': 'v2',
        'extractor_class': 'SessionFeatureExtractorV2',
        'align_hz': float(ALIGN_HZ),
    }


# def extract_session(raw_session, user_id, templates,
#                     census=None, needs_census=False):
def extract_session(raw_session, user_id, templates,
                    census=None, needs_census=False,
                    columns=None, copy_input=True):


    """
    Run the full chain on ONE raw backend session.

    `raw_session` is the object app/services/scoring.py posts, i.e. exactly what
    BehavioralData.get_session_by_id() returns.

    IT IS DEEP-COPIED FIRST, and a shallow copy is not enough. Both
    behavior_cleaner.clean_session and new_sensor_sanitizer.sanitize_view repair
    IN PLACE, reaching into the nested key_events / touch_events lists and the
    per-sensor sample arrays. A `dict(raw_session)` shares all of those, so the
    caller's payload comes back mutated and a second extraction of the same
    object silently runs on already-repaired data. The first parity test hit
    exactly that and produced a double-sanitised second reading. 167 ms on a 3.5 MB session, against 9-17 s of extraction.

    Returns (row, diagnostics). Raises ExtractionError only when the session
    cannot be represented at all; a merely poor session comes back with
    diagnostics saying so, and the caller decides.
    """
    started = time.perf_counter()

    if not isinstance(raw_session, dict):
        raise ExtractionError('session payload is %s, not an object'
                              % type(raw_session).__name__)

    # v3 sends sensor_samples; v1 sent a fused sensor_events list that
    # new_adapid_schema deliberately does not support. Saying so here is far
    # more useful than 5,000 zero-valued columns, which is what the previous
    # service did with exactly this payload.
    samples = raw_session.get('sensor_samples')
    if not samples:
        if raw_session.get('sensor_events'):
            raise ExtractionError(
                'session carries legacy v1 `sensor_events`; this pipeline reads '
                'schema-v3 `sensor_samples` only (new_adapid_schema: "The v2 '
                'sensor_events row-aligned shape is NOT supported")')
        raise ExtractionError('session carries no `sensor_samples`')

    # raw = copy.deepcopy(raw_session)             # see the docstring
    # copy_input=False only from predict(): the request's session is parsed per
    # request and never read again (verified: 302,005 values, 0 differences).
    raw = copy.deepcopy(raw_session) if copy_input else raw_session

    normalize_upload_shape(raw)

    diagnostics = {
        'used_census': False,
        'needs_census': bool(needs_census),
        'census_available': census is not None,
    }

    # ---- 1. behaviour clean (ALWAYS; pass A is census-independent) ---------
    if census is None:
        raise ExtractionError(
            'no per-user census attached to this bundle. behavior_cleaner '
            'repairs 72.6% of sessions and its pass-A repairs move key_* and '
            'touch_* features directly; running without it does not reproduce '
            'the training features. Rebuild the bundle with '
            'enrollment_service.py, which always attaches the census.')
    BC.clean_session(raw, census)
    diagnostics['used_census'] = True
    diagnostics['bc_verdict'] = (raw.get('_clean') or {}).get('bc_verdict')

    # ---- 2. parse ----------------------------------------------------------
    view = SCH.SessionView(raw, user_id=user_id, align_hz=ALIGN_HZ)

    # ---- 3. capabilities from the census, not from this one session --------
    view.bclean = (raw.get('_clean') or {})
    view.recompute_caps(census)

    # ---- 4. sensor sanitiser (always) --------------------------------------
    san = SAN.sanitize_view(view)
    diagnostics['san_verdict'] = san.get('san_verdict')
    diagnostics['san_repaired'] = int(san.get('san_repaired') or 0)
    diagnostics['san_streams_dead'] = int(san.get('san_streams_dead') or 0)
    diagnostics['san_reason'] = (san.get('san_reason') or '')[:200]

    # ---- 5. features -------------------------------------------------------
    # row = _EXTRACTOR.extract(view, templates, None)
    row = _extract_row(view, templates, columns)

    diagnostics['extract_narrow'] = bool(EXTRACT_NARROW and columns)
    diagnostics['n_columns'] = len(row)
    diagnostics['feat_errors'] = str(row.get('feat_errors') or '')
    diagnostics['feat_n_errors'] = int(float(row.get('feat_n_errors') or 0))
    diagnostics['n_touch'] = len(view.touches)
    diagnostics['n_key'] = len(view.keys)
    diagnostics['n_nav'] = len(view.navs)

    # ---- how this app's identifiers were mapped (payload_canonicalizer) ----
    # Never a failure: an id with no role is listed here so a new app version
    # that renames or adds a field is visible in the logs the same day.
    canon = getattr(view, 'canon', None) or {}
    diagnostics['canon_key_scheme'] = canon.get('key_scheme')
    diagnostics['canon_fields'] = {
        fid: '%s (%s)' % (d.get('role'), d.get('source'))
        for fid, d in (canon.get('fields') or {}).items()}
    diagnostics['canon_screens'] = {
        str(n): d.get('role') for n, d in (canon.get('screens') or {}).items()}
    diagnostics['canon_unmapped_fields'] = list(canon.get('unmapped_fields') or [])
    diagnostics['canon_unmapped_screens'] = [
        str(s) for s in (canon.get('unmapped_screens') or [])]
    if diagnostics['canon_unmapped_fields']:
        logger.warning('session %s: field id(s) with no canonical role %s - '
                       'add their words to payload_canonicalizer.FIELD_ROLES',
                       raw.get('session_id'),
                       diagnostics['canon_unmapped_fields'])
    diagnostics['streams'] = sorted(view.streams)
    diagnostics['extract_ms'] = round((time.perf_counter() - started) * 1000, 1)

    return row, diagnostics


def load_templates(path):
    """Load a v3 DTW template pickle, refusing anything else.

    COORDINATION_AUDIT.md Sec B.4: the old service's templates used the SAME
    filename pattern with a 10-channel, 5-key structure. Dropping a current
    35-channel template next to one of those loads without error and then feeds
    the extractor a channel dict it only partly recognises. The version assert
    is what makes that impossible rather than merely unlikely.
    """
    import joblib

    if not os.path.exists(path):
        raise ExtractionError('no DTW templates at %s' % path)
    templates = joblib.load(path)
    if not isinstance(templates, dict):
        raise ExtractionError('%s is %s, not a template dict'
                              % (path, type(templates).__name__))

    version = templates.get('template_version')
    if version != 3:
        raise ExtractionError(
            '%s has template_version=%r, expected 3. A pre-v3 template has 10 '
            'channels against v3\'s 35 and would silently under-fill every '
            'dtw_* column.' % (os.path.basename(path), version))
    return templates
