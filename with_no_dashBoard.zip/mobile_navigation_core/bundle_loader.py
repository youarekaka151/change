"""Load and validate a per-user model bundle. Holds no opinion about features.

THE CONTRACT (PHASE2_DESIGN.md Sec 1.8)
---------------------------------------
A bundle is one `<user>_ocsvm.joblib` written by the research pipeline's single
`SessionOCSVM.save()`. Across 15 model directories and 100 bundles - rev4,
v4_v2, v6, v7, v8, cross-user, no-grvyaw - the key set is identical and the
feature count varies (17, 19, 47, 49, 50, 114). So this loader reads:

    feature_columns   whatever that bundle selected, in that bundle's order
    threshold         that user's calibrated operating point
    params            nu / gamma / gamma_used / kernel / calibrate_method
    provenance        attached at packaging - by package_ml_bundle.py for the
                      8 research-built bundles, by enrollment_service.py for
                      every user enrolled in-server since; see below

and holds NO feature list, NO feature count, NO selection name and NO user list
of its own. Swapping rev4 for a v6 output for one user is a file replacement.
This is the memory principle "no hardcoded feature counts" applied to model and
feature-list selection, not just to k.

WHY PROVENANCE IS REQUIRED RATHER THAN OPTIONAL
-----------------------------------------------
Measured in PHASE2_DESIGN.md Sec 1.3: a shippable rev4 bundle and a v7
ceiling-probe bundle are indistinguishable field by field. Both have the same
nine keys, the same params shape, the same drop_report. `eval_attackers` is not
a discriminator (None for the v7 probe, but also None for v4_v2, which is not a
probe). And the fingerprint fallback - matching feature_columns against the
selection JSONs - ALREADY FAILS on a real artifact in this repo
(models_v4_v2/*.joblib matches nothing on disk), quite apart from the selection
JSONs not existing on a deployed host at all.

So viability cannot be recovered at load time. It has to be stamped at
packaging time, and a bundle without it is refused - per request, not by
crashing the service. A raw SessionOCSVM.save() output has none, which is
intended: the service should not serve an artifact nobody has labelled.

`deployable: false` is NOT refused. Serving ceiling-probe selections is the
explicit purpose of this design - they are experiments. They are served with
`model_uncertified: true` and a warning string, which the backend's _small()
helper preserves into its verdict store.
"""

from __future__ import annotations

import glob
import logging
import os
import threading
from collections import OrderedDict

import joblib
import numpy as np

logger = logging.getLogger(__name__)

BUNDLE_SUFFIX = '_ocsvm.joblib'

# Written by new_train_session.SessionOCSVM.save(). Validated, not assumed:
# PHASE2_DESIGN.md Part 5 item 1 notes a future trainer could diverge.
REQUIRED_KEYS = ('user_id', 'model', 'scaler', 'feature_columns',
                 'threshold', 'params')


class ArtifactError(RuntimeError):
    """A bundle is missing, malformed, or unlabelled. Fails the request."""


class Bundle:
    """One user's model, scaler, feature list, threshold and provenance."""

    __slots__ = ('user_id', 'model', 'scaler', 'feature_columns', 'threshold',
                 'params', 'provenance', 'frozen_state', 'path', 'n_features')

    def __init__(self, raw, path):
        self.path = path

        missing = [k for k in REQUIRED_KEYS if k not in raw]
        if missing:
            raise ArtifactError(
                '%s is not a recognised bundle: missing %s. Expected the nine '
                'keys written by new_train_session.SessionOCSVM.save().'
                % (os.path.basename(path), ', '.join(missing)))

        self.user_id = raw['user_id']
        self.model = raw['model']
        self.scaler = raw['scaler']
        self.feature_columns = list(raw['feature_columns'])
        self.threshold = float(raw['threshold'])
        self.params = dict(raw.get('params') or {})
        self.provenance = raw.get('provenance')
        self.frozen_state = raw.get('frozen_state') or {}
        self.n_features = len(self.feature_columns)

        self._validate_shapes()
        self._validate_provenance()

    # ---------------------------------------------------------------- 2b
    def _validate_shapes(self):
        """
        len(feature_columns) == model.n_features_in_ == scaler.n_features_in_.

        A bundle whose column list and estimators disagree would still score -
        numpy would happily accept a vector of the wrong length only if it
        matched by accident, and otherwise raise somewhere deep in sklearn. The
        failure is much cheaper to read here.
        """
        if self.n_features == 0:
            raise ArtifactError('%s has an empty feature_columns'
                                % os.path.basename(self.path))

        for name, obj in (('model', self.model), ('scaler', self.scaler)):
            n = getattr(obj, 'n_features_in_', None)
            if n is None:
                continue                     # not every estimator exposes it
            if int(n) != self.n_features:
                raise ArtifactError(
                    '%s: feature_columns has %d entries but %s.n_features_in_ '
                    'is %d' % (os.path.basename(self.path), self.n_features,
                               name, int(n)))

        duplicates = len(self.feature_columns) - len(set(self.feature_columns))
        if duplicates:
            raise ArtifactError('%s: feature_columns contains %d duplicate(s)'
                                % (os.path.basename(self.path), duplicates))

    # ---------------------------------------------------------------- 2c/2e
    def _validate_provenance(self):
        if not isinstance(self.provenance, dict) or not self.provenance:
            raise ArtifactError(
                '%s carries no `provenance` block, so its viability is '
                'unknown and it cannot be reported honestly. Bundles are '
                'built by enrollment_service.py, which always attaches one; '
                'this file came from somewhere else.'
                % os.path.basename(self.path))

        for key in ('deployable', 'extractor', 'needs_census'):
            if key not in self.provenance:
                raise ArtifactError(
                    '%s: provenance is missing `%s`'
                    % (os.path.basename(self.path), key))

        extractor = self.provenance.get('extractor')
        if extractor != 'v2':
            raise ArtifactError(
                '%s: provenance says extractor=%r. This service runs the v2 '
                'extractor only (PHASE2_DESIGN.md Sec 1.6).'
                % (os.path.basename(self.path), extractor))

    # ------------------------------------------------------------- reporting
    @property
    def needs_census(self):
        return bool(self.provenance.get('needs_census'))

    @property
    def census(self):
        return self.frozen_state.get('clean_census')

    @property
    def uncertified(self):
        """True unless the source selection was explicitly marked deployable."""
        return self.provenance.get('deployable') is not True

    def warning(self):
        """One short sentence for the response. None when the model is clean."""
        if not self.uncertified:
            return None
        p = self.provenance
        bits = []
        if p.get('probe'):
            bits.append('probe=%s' % p['probe'])
        if p.get('contaminated'):
            bits.append('trained with impostors visible during selection')
        if p.get('deployable') is None:
            bits.append('viability unknown')
        source = p.get('selection_file') or 'unknown selection'
        return ('UNCERTIFIED model (%s): %s. Do not report FAR/TAR from it.'
                % (source, '; '.join(bits) or 'not marked deployable'))

    def describe(self):
        """Scalar-only summary. Safe for the HTTP response and for _small()."""
        p = self.provenance or {}
        return {
            'user_id': self.user_id,
            'n_features': self.n_features,
            'threshold': self.threshold,
            'extractor': p.get('extractor'),
            'feature_set_sha256': p.get('feature_set_sha256'),
            'selection_file': p.get('selection_file'),
            'trainer': p.get('trainer'),
            'model_built_at': p.get('built_at'),
            'model_deployable': p.get('deployable'),
            'model_probe': p.get('probe'),
            'model_contaminated': p.get('contaminated'),
            'model_uncertified': self.uncertified,
            'needs_census': self.needs_census,
        }

    # ---------------------------------------------------------------- scoring
    def vectorise(self, row):
        """
        Pull this bundle's columns out of an extracted row, in bundle order.

        Missing or non-finite is an ERROR, never a zero. Gap 7: the previous
        service substituted 0.0 for anything it could not compute, the scaler
        turned each 0.0 into a large constant z-score, and the RBF saturated to
        a session-independent -rho. Refusing is the entire fix.
        """
        missing, nonfinite = [], []
        values = np.empty(self.n_features, dtype=np.float64)

        for i, column in enumerate(self.feature_columns):
            if column not in row:
                missing.append(column)
                values[i] = 0.0
                continue
            try:
                value = float(row[column])
            except (TypeError, ValueError):
                nonfinite.append(column)
                values[i] = 0.0
                continue
            if not np.isfinite(value):
                nonfinite.append(column)
                values[i] = 0.0
                continue
            values[i] = value

        if missing or nonfinite:
            raise ArtifactError(
                'cannot build a feature vector for %s: %d missing (%s), '
                '%d non-finite (%s). Not substituting zeros - see Gap 7.'
                % (self.user_id, len(missing), ', '.join(missing[:5]) or '-',
                   len(nonfinite), ', '.join(nonfinite[:5]) or '-'))

        return values.reshape(1, -1)

    def score(self, row):
        """Decision value for one extracted row, on this bundle's own scale."""
        X = self.vectorise(row)
        return float(self.model.decision_function(self.scaler.transform(X))[0])

    def decide(self, score):
        """Genuine iff score >= threshold (new_train_session.py:759-760)."""
        return bool(score >= self.threshold)


class BundleStore:
    """
    Thread-safe, lazily-filled, LRU-bounded cache of (bundle, templates).

    Bounded because users are enrolled in-server now and the count only grows;
    each entry is a few hundred KB per gunicorn worker. The pair is ONE value,
    so an eviction can never leave a bundle cached without its templates.
    Misses are never cached: a first enrolment is picked up on the next
    request. A bundle is never overwritten on disk (enrollment_service), so a
    cached entry can never be stale.
    """

    def __init__(self, models_dir='models', templates_dir='templates',
                 max_entries=None):
        self.models_dir = models_dir
        self.templates_dir = templates_dir
        self.max_entries = max(1, int(max_entries or os.getenv('ML_CACHE_MAX', 256)))
        self._cache = OrderedDict()               # user_id -> (bundle, templates)
        self._lock = threading.Lock()

    # ------------------------------------------------------------ discovery
    def cached_users(self):
        with self._lock:
            return list(self._cache)

    def available_users(self):
        """Every bundle on disk. O(users): for boot and tests, never per request."""
        out = []
        for path in sorted(glob.glob(os.path.join(self.models_dir,
                                                  '*' + BUNDLE_SUFFIX))):
            out.append(os.path.basename(path)[:-len(BUNDLE_SUFFIX)])
        return out

    def bundle_path(self, user_id):
        return os.path.join(self.models_dir, '%s%s' % (user_id, BUNDLE_SUFFIX))

    def template_path(self, user_id):
        return os.path.join(self.templates_dir,
                            '%s_dtw_templates.pkl' % user_id)

    # ---------------------------------------------------------------- access
    def get(self, user_id):
        """(bundle, templates) for one user. Raises ArtifactError."""
        if not user_id:
            raise ArtifactError('no user_id given')

        with self._lock:
            cached = self._cache.get(user_id)
            if cached is not None:
                self._cache.move_to_end(user_id)
        if cached is not None:
            return cached

        bundle_path = self.bundle_path(user_id)
        if not os.path.exists(bundle_path):
            # No listing of who IS enrolled: it cost a directory glob per miss
            # and handed every caller the user list.
            raise ArtifactError(
                "no model for user %r (looked for %s): not enrolled yet"
                % (user_id, os.path.basename(bundle_path)))

        try:
            raw = joblib.load(bundle_path)
        except Exception as error:                   # noqa: BLE001
            raise ArtifactError('cannot load %s: %s'
                                % (os.path.basename(bundle_path), error))

        bundle = Bundle(raw, bundle_path)
        if bundle.user_id != user_id:
            raise ArtifactError(
                '%s contains a model for %r, not %r'
                % (os.path.basename(bundle_path), bundle.user_id, user_id))

        # Imported here so this module stays importable without the vendor tree
        # (the packaging script and tests reuse Bundle on its own).
        from feature_extraction import ExtractionError, load_templates
        # Wrapped: callers (prediction_service.predict) catch ArtifactError
        # only, so a missing or pre-v3 template used to surface as a 500.
        try:
            templates = load_templates(self.template_path(user_id))
        except (ExtractionError, OSError) as error:
            raise ArtifactError('templates for %r: %s' % (user_id, error))
        except Exception as error:                    # noqa: BLE001  unpickling
            raise ArtifactError('cannot load templates for %r: %s'
                                % (user_id, error))

        # The census is required for EVERY bundle, not only the ones the
        # needs_census rule flags. behavior_cleaner.clean_session runs
        # unconditionally (see feature_extraction's docstring: its pass-A
        # repairs are census-independent and fire on 72.6% of sessions), and
        # clean_session takes the census as a positional argument. needs_census
        # only records whether this bundle's own features depend on pass B.
        if bundle.census is None:
            raise ArtifactError(
                '%s carries no frozen_state.clean_census. Every bundle needs '
                'one: behavior_cleaner runs on every session. Rebuild it with '
                'enrollment_service.py, which always attaches the census.'
                % os.path.basename(bundle_path))

        with self._lock:
            self._cache[user_id] = (bundle, templates)
            self._cache.move_to_end(user_id)
            while len(self._cache) > self.max_entries:
                self._cache.popitem(last=False)
        logger.info('loaded %s: %d features, threshold %+.6f, %s',
                    user_id, bundle.n_features, bundle.threshold,
                    'UNCERTIFIED' if bundle.uncertified else 'deployable')
        return bundle, templates

    def warm(self, limit=None):
        """
        Load bundles at boot, at most `limit` (never more than the cache
        holds). Returns {user: ok|error}. Under preload_app this runs in the
        gunicorn master, so every worker inherits the loaded entries.
        """
        report = {}
        users = self.available_users()
        limit = self.max_entries if limit is None else min(int(limit), self.max_entries)
        for user_id in users[:max(0, limit)]:
            try:
                self.get(user_id)
                report[user_id] = 'ok'
            except Exception as error:               # noqa: BLE001
                report[user_id] = str(error)
                logger.error('cannot warm %s: %s', user_id, error)
        return report
