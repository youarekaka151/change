"""Score one stored behavioural session against that user's enrolled model.

WHAT THIS REPLACED, AND THE ONE MEASUREMENT THAT DROVE IT
----------------------------------------------------------
The previous implementation carried its own 2,420-line feature extractor that
read schema-v1 `sensor_events`. The backend has sent schema-v3 `sensor_samples`
since the v3 rollout, so 82 of its 96 trained columns were silently filled with
0.0, the scaler turned each 0.0 into a large constant z-score, and the RBF
kernel saturated. Measured (COORDINATION_AUDIT.md Part 0):

    two different sessions, same user -> decision_function = -1.8935865904
    a vector of 1e6                    -> decision_function = -1.8935865904

It returned a constant `is_genuine: false` for every session ever submitted.

Three rules follow from that, and they are the design:

  1. DO NOT REIMPLEMENT FEATURES. feature_extraction.py calls the vendored
     research closure. There is exactly one definition of every column.
  2. NEVER SUBSTITUTE A ZERO. A feature that cannot be computed fails the
     request. Zero-filling is what made a broken extraction look like a
     confident rejection.
  3. NOTHING IS HARDCODED PER MODEL. The bundle brings its own feature list,
     its own count and its own threshold. Swapping rev4 for a v6 or v8
     experiment is a file replacement, not a code change.

WHAT THE BACKEND NEEDS BACK
---------------------------
app/services/scoring.py requires HTTP 200, `status == 'success'` and the key
`is_genuine` present; `is_genuine` absent is recorded as "no verdict", never as
"impostor". Everything else scalar is preserved by its `_small()` helper into
the verdict store, so score / threshold / margin / the uncertified flag all
survive without any backend change.
"""

from __future__ import annotations

import logging
import os
import sys
import time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

# The directory holding app.py and train_jobs.py, one above this package. A
# relative ML_MODELS_DIR / ML_TEMPLATES_DIR resolves against it and NOT against
# HERE, so the web service and the trainer agree on one set of folders: the
# trainer resolves the same relative paths against its working directory, which
# is this same directory.
APP_ROOT = os.path.dirname(HERE)

logger = logging.getLogger(__name__)


class PredictionService:
    """Owns the boot checks, the artifact cache and the scoring path."""

    def __init__(self, models_dir='models', templates_dir='templates',
                 warm=True, strict_boot=True):
        self.models_dir = os.path.join(APP_ROOT, models_dir) \
            if not os.path.isabs(models_dir) else models_dir
        self.templates_dir = os.path.join(APP_ROOT, templates_dir) \
            if not os.path.isabs(templates_dir) else templates_dir

        # ---- boot checks FIRST -------------------------------------------
        # Vendor integrity, the non-optional "optional" dependencies, a clean
        # FEATURE_EXCLUDE_* environment, and version agreement. A service that
        # cannot verify its own feature code has nothing trustworthy to say, so
        # this is allowed to raise and stop startup.
        from boot_checks import run_boot_checks, format_report
        self.boot_report = run_boot_checks(strict=strict_boot)
        logger.info('boot checks\n%s', format_report(self.boot_report))

        from bundle_loader import BundleStore
        from feature_extraction import extractor_identity

        self.identity = extractor_identity()
        self.store = BundleStore(self.models_dir, self.templates_dir)

        # A count, not the list: users are enrolled in-server now and the list
        # only grows.
        self.n_users_at_boot = len(self.store.available_users())
        logger.info('extractor %s (align_hz=%s), %d enrolled user(s), cache %d',
                    self.identity['extractor'], self.identity['align_hz'],
                    self.n_users_at_boot, self.store.max_entries)

        # Work item 9. Extraction costs seconds and the first import of
        # scipy/tslearn costs seconds more; paying both on a real request would
        # put that latency in front of a participant. Bounded: past ML_WARM_MAX
        # bundles the boot would grow with every enrolment, and the rest load
        # on their first request anyway.
        warm_max = int(os.getenv('ML_WARM_MAX', 50))
        self.warm_report = self.store.warm(limit=warm_max) if warm else {}
        failed = {u: e for u, e in self.warm_report.items() if e != 'ok'}
        if failed:
            for user_id, error in failed.items():
                logger.error('user %s will fail at request time: %s',
                             user_id, error)

        # tslearn.metrics.dtw is numba-jitted: unlike the import above, numba
        # compiles on the first CALL, not on import, and store.warm() above
        # never calls it (joblib.load only touches the pickled arrays). Left
        # unprimed, that one-time compile (~20s+, observed) lands on whichever
        # participant's session is scored first. dtw_distance always calls it
        # with the same signature (1-D float64 arrays) that
        # compute_dtw_features uses at request time, so one throwaway call
        # here compiles it once, at boot, and every real request afterwards -
        # in this and every other worker forked from this preloaded master -
        # reuses the cached compiled function.
        if warm:
            try:
                from new_build_dtw_templates import dtw_distance
                import numpy as _np
                dtw_distance(_np.zeros(8), _np.ones(8))
                logger.info('DTW kernel primed')
            except Exception as error:                    # noqa: BLE001
                logger.warning('could not prime DTW kernel at boot: %s. '
                               'First real request will pay the JIT cost '
                               'instead.', error)

    # ------------------------------------------------------------- helpers
    @staticmethod
    def _unwrap(payload):
        """
        Accept the backend's bare session OR a {"user_id", "sessions":[...]}
        batch.

        scoring.py posts ONE session read back from Oracle, with user_id and the
        event arrays at the top level. A human testing by hand may post the full
        upload payload. Handling both costs four lines and removes a class of
        support question.
        """
        if not isinstance(payload, dict):
            return None, None
        batch = payload.get('sessions')
        if batch:
            session = batch[0] if isinstance(batch, list) else None
            user_id = payload.get('user_id') or (session or {}).get('user_id')
            return session, user_id
        return payload, payload.get('user_id')

    @staticmethod
    def _error(message, code=400, **extra):
        body = {'status': 'error', 'message': str(message)[:500]}
        body.update(extra)
        return body, code

    def calculate_risk_score(self,model_score, dynamic_threshold, k=10):
        """
        Risk score calculation with adjustable steepness.
    
        Args:
            model_score: Model output (range: -8 to 0.8)
            dynamic_threshold: Threshold between legitimate and impostor
            k: Steepness of sigmoid curve (higher = sharper transition)
    
        Returns:
            risk_score: Final risk score (0-100)
        """
        distance = model_score - dynamic_threshold
        sigmoid = 1 / (1 + np.exp(-k * distance))
        risk_score = 100 * (1 - sigmoid)
    
        return round(np.clip(risk_score, 0, 100),2)
    # ------------------------------------------------------------- scoring
    def predict(self, payload):
        """
        Returns a dict (HTTP 200) or a (dict, status_code) tuple on failure.

        `is_genuine` appears ONLY on the success path. The backend treats a
        success-shaped record without it as "no verdict", which is the honest
        outcome whenever the model did not actually get to answer.
        """
        started = time.perf_counter()

        from bundle_loader import ArtifactError
        from feature_extraction import extract_session, ExtractionError

        if payload is None:
            return self._error('request body was empty or not JSON')

        session, user_id = self._unwrap(payload)
        if not session:
            return self._error('no session to score')
        if not user_id:
            return self._error(
                "missing 'user_id'. The backend's get_session_by_id() includes "
                "it; get_latest_user_session() does not (see the audit, Gap 11)")

        session_id = session.get('session_id')

        # ---- artifacts ----------------------------------------------------
        t0 = time.perf_counter()
        try:
            bundle, templates = self.store.get(user_id)
        except ArtifactError as error:
            logger.warning('artifact problem for %s: %s', user_id, error)
            return self._error(error, 400, user_id=user_id,
                               session_id=session_id)
        load_ms = round((time.perf_counter() - t0) * 1000, 1)

        # ---- features -----------------------------------------------------
        try:
            # row, diagnostics = extract_session(
            #     session, user_id, templates,
            #     census=bundle.census, needs_census=bundle.needs_census)
            row, diagnostics = extract_session(
                session, user_id, templates,
                census=bundle.census, needs_census=bundle.needs_census,
                columns=bundle.feature_columns, copy_input=False)

        except ExtractionError as error:
            logger.warning('extraction failed for %s/%s: %s',
                           user_id, session_id, error)
            return self._error(error, 400, user_id=user_id,
                               session_id=session_id)
        except Exception as error:                        # noqa: BLE001
            logger.exception('unexpected extraction error for %s', user_id)
            return self._error('extraction failed: %s' % error, 400,
                               user_id=user_id, session_id=session_id)

        # ---- quality gate --------------------------------------------------
        # sanitize_views() drops EXCLUDE sessions from a research run outright.
        # A service cannot drop a request, so it reports instead. Scoring a
        # session the sanitiser judged unusable would produce a number with no
        # meaning, and the backend would store it as a real verdict.
        if diagnostics.get('san_verdict') == 'EXCLUDE':
            return self._error(
                'session rejected by the sensor sanitiser: %s'
                % (diagnostics.get('san_reason') or 'san_verdict=EXCLUDE'),
                400, user_id=user_id, session_id=session_id,
                san_verdict='EXCLUDE')

        # ---- score ---------------------------------------------------------
        t1 = time.perf_counter()
        try:
            score = bundle.score(row)
        except ArtifactError as error:
            # Missing or non-finite feature. This is the Gap 7 path: refuse,
            # never zero-fill.
            logger.warning('vector build failed for %s/%s: %s',
                           user_id, session_id, error)
            return self._error(error, 400, user_id=user_id,
                               session_id=session_id)
        score_ms = round((time.perf_counter() - t1) * 1000, 1)

        is_genuine = bundle.decide(score)
        described = bundle.describe()
        warning = bundle.warning()
        risk_score = self.calculate_risk_score(model_score=round(score, 8),dynamic_threshold=round(bundle.threshold, 8))


        response = {
            'status': 'success',
            'is_genuine': is_genuine,
            'user_id': user_id,
            'risk_score':risk_score,
            'session_id': session_id,
            'score': round(score, 8),
            'threshold': round(bundle.threshold, 8),
            'margin': round(score - bundle.threshold, 8),
            'n_features': described['n_features'],
            'extractor': described['extractor'],
            'feature_set_sha256': (described['feature_set_sha256'] or '')[:16],
            'selection_file': described['selection_file'],
            'model_deployable': described['model_deployable'],
            'model_probe': described['model_probe'],
            'model_contaminated': described['model_contaminated'],
            'model_uncertified': described['model_uncertified'],
            'san_verdict': diagnostics.get('san_verdict'),
            'used_census': diagnostics.get('used_census'),
            'load_ms': load_ms,
            'extract_ms': diagnostics.get('extract_ms'),
            'score_ms': score_ms,
            'total_ms': round((time.perf_counter() - started) * 1000, 1),
        }
        if warning:
            response['model_warning'] = warning
        if diagnostics.get('feat_n_errors'):
            response['feat_n_errors'] = diagnostics['feat_n_errors']

        logger.info(
            '%s/%s -> %s score=%+.6f thr=%+.6f margin=%+.6f k=%d %s '
            '(load=%.0fms extract=%.0fms score=%.0fms total=%.0fms)',
            user_id, session_id, 'GENUINE' if is_genuine else 'IMPOSTER',
            score, bundle.threshold, score - bundle.threshold,
            described['n_features'],
            'UNCERTIFIED' if described['model_uncertified'] else 'deployable',
            load_ms, diagnostics.get('extract_ms') or 0, score_ms,
            response['total_ms'])
        return response

    # -------------------------------------------------------------- status
    def health_check(self):
        return {'status': 'live'}

    def info(self):
        """
        What is deployed. Describes only bundles ALREADY in memory: loading
        every user's bundle here would make this O(users) and churn the LRU.
        """
        loaded = {}
        for user_id in self.store.cached_users():
            try:
                bundle, _ = self.store.get(user_id)
            except Exception as error:                    # noqa: BLE001
                loaded[user_id] = {'error': str(error)[:200]}
                continue
            loaded[user_id] = bundle.describe()
        warm_failed = {u: e for u, e in self.warm_report.items() if e != 'ok'}

        return {
            'service': 'ADAPID ML prediction API',
            'endpoints': {
                'health': 'GET /nav/ai/health',
                'predict': 'POST /nav/ai/predict',
                'info': 'GET /nav/ai/info',
                'train': 'POST /nav/ai/train, GET /nav/ai/train/<user_id>',
            },
            'extractor': self.identity,
            'n_users': len(self.store.available_users()),
            'n_loaded': len(loaded),
            'cache_max': self.store.max_entries,
            'loaded': loaded,
            'warm': {'n': len(self.warm_report), 'failed': warm_failed},
            'status': 'running',
        }
