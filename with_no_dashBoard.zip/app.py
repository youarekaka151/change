"""
adapID mobile navigation ML API code entry point

THE ENDPOINT CONTRACT IS UNCHANGED AND MUST STAY UNCHANGED. The paths are what
NAV already calls; this file only registers the blueprint that answers each one.

Run it from the REPO ROOT, not from this folder: ML_MODELS_DIR, ML_TEMPLATES_DIR
and ML_JOBS_DIR default to relative paths that resolve against the working
directory.

    python Structure_code/app.py
    gunicorn -c nginx/gunicorn.config.py --chdir Structure_code app:app
"""

import logging
import os


try:                                    # local dev: read .env BEFORE anything is built
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:                     # production image has no python-dotenv: env comes from ECS
    pass


# First: importing `common` puts the project root on sys.path, which is what
# makes the feature packages' own root-level imports resolvable.
import common                                            # noqa: F401

from flask import Flask, jsonify

from utils.config import setup_logging
from mobile_navigation_model_health.view import mobile_navigation_health_api
from mobile_navigation_model_predict.view import mobile_navigation_predict_api
from mobile_navigation_model_train.view import mobile_navigation_model_train_api
from mobile_navigation_model_train_status.view import mobile_navigation_model_train_status_api
from mobile_navigation_model_info.view import mobile_navigation_model_info_api

setup_logging()
logger = logging.getLogger(__name__)

app = Flask(__name__)

app.register_blueprint(mobile_navigation_health_api)
app.register_blueprint(mobile_navigation_predict_api)
app.register_blueprint(mobile_navigation_model_train_api)
app.register_blueprint(mobile_navigation_model_train_status_api)
app.register_blueprint(mobile_navigation_model_info_api)


@app.errorhandler(404)
def not_found(error):
    return jsonify({'status': 'error', 'message': 'Endpoint not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    logger.error('Internal server error: %s', error)
    return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


if __name__ == '__main__':
    # debug=False deliberately: the reloader would run the boot checks and warm
    # every bundle twice, and the interactive debugger has no place in front of
    # a service that handles behavioural data.
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', '5000')),
            debug=False, threaded=True)
