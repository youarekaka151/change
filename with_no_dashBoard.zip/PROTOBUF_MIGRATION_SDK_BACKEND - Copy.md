# Protobuf migration — shared schema, SDK/APK and DB backend

Scope: everything except the ML service. ML-side changes are in
`PROTOBUF_MIGRATION_ML.md`.

Repos covered:

| Repo | Path | Role |
|---|---|---|
| SDK + host app | `TestTotpDCBShaswat/` | collects behaviour, uploads it |
| DB backend | `Archive 1/` | validates, stores in Oracle, serves ML |

Every file:line reference below was read directly from those trees.

---

## 1. The behavioural data path

Four wire hops and five at-rest formats carry behavioural data. The ~242 other
JSON sites in the backend (dashboard UAM, `silent_totp`, reports, admin login)
are small request/response bodies where protobuf gains nothing and would force
a frontend rewrite. **They are out of scope.**

### Wire hops

| # | Hop | Current | Producer | Consumer |
|---|---|---|---|---|
| W1 | SDK -> backend upload | JSON + optional gzip | `Keydata.buildPayload()` -> `compactGson.toJson()` -> `postBody()` | `CombinedMobileApi.post()` -> `get_request_json()` |
| W2 | backend -> ML training pull | JSON (`jsonify`) | `MobilePatternFetchSessionsApi.get()` | `NavFetch._get()` (ML side) |
| W3 | backend -> ML predict | `json.dumps` + optional zstd | `_predict_body()` | `_extract_payload()` (ML side) |
| W4 | backend -> keystroke AI (`mbkst-ai`) | JSON | `mobile_core_api.py:132,235,418` | **external service — code not in any of these repos** |

### At rest

| # | Where | Current |
|---|---|---|
| R1 | SDK on device | `meta.json` + `sensors.jsonl` crash checkpoint, plus debug payload copies |
| R2 | Oracle CLOB columns | `COORD_FRAME`, `FIELDS_JSON`, `SCREENS_JSON`, `VALUES_JSON`, `DETAILS_JSON`, `DEVICE_DETAILS`, `behaviour_data` (AES(JSON)), `feature_vectors`, `user_ip_info` |
| R3 | Celery broker | `authn_store.pack()` = base64(zlib(JSON)); `celery_worker.py:21-23` pins `task_serializer='json'` |
| R4 | ML staging envelope | `sessions.json` — covered in the ML doc |
| R5 | ML config/selection | `features/*.json`, job state — **leave as JSON** |

### Recommended scope

Convert **W1, W2, W3** and the ML staging file. Leave **W4, R1, R2, R3, R5** on
JSON. Reasons given per section below.

---

## 2. Shared artifact: `adapid_behaviour_v1.proto`

One folder/repo owning the schema, compiled to Kotlin (javalite) and Python.
Field numbers frozen on first release.

```
BehaviourUpload  { username, profile_type, ip_address, activity,
                   BehaviourData behaviour_data, repeated Session sessions }

BehaviourData    { repeated KeystrokeEvent keystroke }
KeystrokeEvent   { key, keydown_time, keyup_time,
                   is_repeat, key_type, field_role, field_id }

Session          { session_id, session_type, label, operator_id, schema_version,
                   session_start_ts, session_end_ts, start_rotation,
                   was_resumed, recovery_reason,
                   repeated ResumeEvent resume_events,
                   contract_version, app_id, app_version, app_version_code,
                   sdk_version, keyboard_source, key_label_scheme,
                   CoordFrame coord_frame,
                   repeated Screen screens,
                   repeated Field fields,
                   DeviceInfo device_info,
                   Sampling sampling,
                   repeated NavigationEvent navigation_events,
                   repeated OrientationEvent orientation_events,
                   repeated TouchEvent touch_events,
                   repeated KeyEvent key_events,
                   repeated SensorSample sensor_samples }

DeviceInfo       { device_id, install_id, platform, os_version, app_version,
                   screen_width, screen_height, screen_density,
                   power_save_mode, thermal_status, refresh_rate_hz,
                   repeated SensorMeta sensors, repeated TouchAxis touch_axes }

Sampling         { mode, active_hz, idle_hz, idle_after_ms,
                   rate_switch_count, dropped_sample_count,
                   max_report_latency_us,
                   session_truncated, truncation_reason, truncated_at_ts,
                   map<string,int64> truncated_streams,
                   dropped_pre_session_count,
                   map<string,int64> stream_first_sample_ts,
                   batched_sample_count, clock_fallback_count,
                   repeated string clock_fault_streams }

SensorMeta, TouchAxis, CoordFrame, Screen, ResumeEvent, Field, Bounds,
NavigationEvent, TouchEvent, PathPoint, KeyEvent, SensorSample,
OrientationEvent

SessionsResponse { success, message, Data data }        // W2
Data             { user_id, Profile profile, total_sessions,
                   returned_sessions, include_events, limit, offset }
Profile          { id, user_id, profile_type, created_at }
```

Field lists are taken from `Keydata.buildPayload()` (`:1513-1578`) and the
backend's mapping tables (`store_user_behaviour_data_svm_pattern.py:21-112`).
Note `Sampling` above includes the nine diagnostics the backend currently drops
— see §6.

### 2.1 `optional` on every scalar — mandatory

proto3 scalars cannot distinguish absent from `0` / `""` / `false`. Five places
depend on that distinction:

| Where | Depends on absence |
|---|---|
| `store_user_behaviour_data_svm_pattern.py:115-125` `_convert` | returns `None` -> Oracle `NULL` |
| `mobile_pattern_fetch_sessions_api.py:58-60` `_num` | `float(v) if v is not None else None` |
| `SensorDataCollector.addSample` `:745-755` | writes **explicit** `JsonNull` for `x/y/z/w/heading_accuracy_rad` |
| `KeyEventModel` `:24,25,35` | `keyCode`, `digit`, `touchSeq` are nullable and sent as explicit `null` |
| `Keydata.sanitizeSensorSamples` `:1433-1442` | **purges** null keys — absence is already the convention |

Plus the ML side turns missing numerics into `np.nan`, which drives the
`*_measurable` flags and the enrolment refusal gates
(`enrollment_service.py:472-484`).

Use `optional` (protobuf >= 3.15) on every scalar; map `!has_x()` to
Kotlin `null` / Python `None`.

### 2.2 Float precision — read before choosing `float` vs `double`

Today's chain is **not** a plain float32 widening:

| Step | Value |
|---|---|
| Kotlin `Float` | `0.1f` |
| Gson writes shortest round-trip text | `"0.1"` |
| Python `json.loads` | float64 `0.1` |
| Oracle `NUMBER` (decimal) | exactly `0.1` |
| Read back via `_num()` | `0.1` |
| A proto `double` carrying `0.1f` widened | `0.10000000149011612` |

So a naive `double` field changes every coordinate, pressure and sensor reading
that was ever float32 — and therefore every feature derived from them.

**Fix**: in the SDK, convert `Float -> Double` via shortest-repr round-trip
(`value.toString().toDouble()`) before setting a proto `double`.

Applies to every `Float` in `SensorDataCollector` (`x`, `y`, `pressure`, `size`,
`touch_major/minor`, `tool_major/minor`, `raw_x/y`, `up_*`, `edge_distance_px`)
and `KeyEventModel.edgeDistancePx`.

### 2.3 `values` / `n_values`

The SDK enforces `values.length == n_values` in `sanitizeSensorSamples`
(`:1414-1431`) — this was flaw 17, where rotation_vector samples claimed 5
values but carried 3.

In protobuf `n_values` is redundant (`values.size`), **but keep the field**:
`NAV_SENSOR_SAMPLES.N_VALUES` is a real column and the ML side reads it. Keep
the rebuild logic, drop nothing.

---

## 3. SDK / APK — `TestTotpDCBShaswat`

### 3.1 Build files

| File | Change |
|---|---|
| `SdkTOTP/app/build.gradle.kts` (`:269-314`) | add `com.google.protobuf` gradle plugin + `protobuf-javalite`. **javalite, not full** — full protobuf adds ~1 MB and reflection you don't need. Keep Gson (`:289`) — still used by FIDO, TOTP and `model/`. Keep retrofit + converter-gson (`:279-281`) |
| `SdkTOTP/gradle/libs.versions.toml` | register plugin + version |
| `SdkTOTP/build.gradle.kts` (root) | declare the plugin `apply false` |
| `SdkTOTP/app/proguard-rules.pro` | add `-keep class com.google.protobuf.** { *; }` and `-keepclassmembers class * extends com.google.protobuf.GeneratedMessageLite { <fields>; }`. Existing Gson keeps stay |

### 3.2 `KeyData/Keydata.kt` — the payload builder (2,164 lines; largest change)

| Function | Line | Change |
|---|---|---|
| `buildPayload()` | 1513-1578 | `JsonObject` -> `BehaviourUpload.Builder`. Root change |
| `buildDeviceInfo()` | 1228-1272 | -> `DeviceInfo.Builder` |
| `buildSensorMeta()` | 1274-1296 | -> `SensorMeta.Builder` |
| `buildCoordFrame()` | 1311-1320 | -> `CoordFrame.Builder` |
| `buildScreens()` | 1322-1339 | -> `repeated Screen`. Reads `resumeEvents` back via `.get("screen_id").asString` at `:1332` — becomes typed access |
| `buildSampling()` | 1341-1379 | -> `Sampling.Builder`. The two inline maps (`truncated_streams` `:1362-1364`, `stream_first_sample_ts` `:1368-1370`) become proto `map<string,int64>` |
| `buildNavigationEvents()` | 951-967 | -> `repeated NavigationEvent` |
| `sanitizeSensorSamples()` | 1389-1447 | **Keep** the screen fix (`:1399-1403`) and the values/n_values rebuild (`:1414-1431`). **Delete** the null-purge loop (`:1433-1442`) — field presence replaces it |
| `sanitizeTouchEvents()` | 1450-1511 | **Keep** the screen fix and the explicit `orientation` / `up_orientation` = 0.0 (`:1467-1472`). Do **not** drop that: `ORIENTATION` currently stores 0, not NULL. **Delete** the null-purge loops (`:1486-1490`, `:1498-1506`) |
| `submitData()` | 1582-1646 | the motion-sensor preflight at `:1610-1613` reads `rawSensorSamples.get(i).asJsonObject.get("sensor_type")` -> typed iteration. **Keep the check** — it rejects a session with no accelerometer/gyroscope |
| `sendToApi()` | 1734-1787 | serialize with `toByteArray()`. **Keep** the HTTP 415 retry at `:1757-1760` and add the analogous content-type fallback |
| `postBody()` | 1791-1820 | `Content-Type: application/x-protobuf` at `:1800`; `Accept` at `:1801` |
| `compressBestEffort()` | 1715-1732 | **keep as-is.** gzip over protobuf still helps, and the byte-for-byte round-trip verification at `:1721-1726` is worth keeping |
| `SaveCallback.onSaved(filePath, payload: String)` | 759-764 | public API. See §3.7 |
| `saveDataLocally()` / `saveJsonDebugFile()` | 1838-1863 / 1665-1693 | debug sinks. See §3.6 |
| `snapshotKeydataState()` / `restoreKeydataState()` / `resumeRecord()` | 2018-2036 / 2038-2075 / 2128-2141 | checkpoint format. See §3.6 |

### 3.3 `KeyData/SensorDataCollector.kt` — the invasive one (1,320 lines)

**This file uses Gson as its in-memory data structure**, not just for
serialization:

- `touchEvents`, `sensorSamples`, `navigationEvents`, `orientationEvents` are
  `JsonArray` fields (`:242-245`)
- `ActiveTouch.path` is a `JsonArray` (`:379`)
- `classifyGesture()` (`:1107-1127`) **reads x/y/t back out** of path JsonObjects
- `buildCancelledTouchRecord()` (`:988-1079`) reads the first and last path
  points back out
- `captureTouch` ACTION_MOVE (`:830-833`) reads the last path point's x/y

**Two options:**

| | Approach | Pros | Cons |
|---|---|---|---|
| **(a)** | Convert the buffers to proto builders | Removes the ~1.4 KB/sample heap cost cited at `:273-277` as the reason `MAX_SENSOR_SAMPLES` is capped at 40,000. Removes the extra copy at submit. Real headroom gain | Larger diff; `classifyGesture` and `buildCancelledTouchRecord` need rewriting against typed accessors |
| **(b)** | Keep Gson in memory, convert once at submit | Much smaller diff; sanitizers unchanged | Memory ceiling and double copy stay |

Functions touched either way: `addSample()` `:733-765`, `addSample3Axis()`
`:725-731`, `rawValuesOf()` `:768-772`, `captureTouch()` `:783-869`,
`buildTouchRecord()` `:872-919`, `addEdgeInfo()` `:926-929`,
`buildCancelledTouchRecord()` `:988-1079`, `classifyGesture()` `:1107-1127`,
`pathPoint()` `:1130-1146`, `addNavigationEvent()` `:1148-1158`, the getters
`:1160-1163`, `sensorSamplesFrom()` `:1241-1247`, `snapshotState()`
`:1250-1268`, `restoreState()` `:1277-1310`, `longMapJson()` / `readLongMap()`
`:1312-1320`.

**Do not touch**: the sensor budget logic (`admitSample` `:596-614`,
`noteDrop` `:616-631`), the clock handling (`onSensorChanged` `:519-571`), rate
decimation (`:646-654`), or the edge-zone calculation (`:932-960`). All
format-independent, all encode measured fixes.

### 3.4 `KeyData/KeyStrokeManager.kt` — clean and easy (611 lines)

`keyEvents` is already `mutableListOf<KeyEventModel>()` (`:153`) — a Kotlin data
class, **no JSON in memory**. Only the output boundary changes:

| Function | Line | Change |
|---|---|---|
| `getEventsAsJson()` | 406-422 | -> `List<KeystrokeEvent>` for W4 |
| `getSessionKeyEventsJson()` | 428-474 | -> `List<KeyEvent>` |
| `fieldsJson()` | 231-261 | -> `List<Field>` (incl. `Bounds` at `:252-257`) |
| `snapshotKeyEvents()` / `restoreKeyEvents()` | 479-493 | checkpoint; see §3.6 |

**Critical**: keep the two streams separate. `behaviour_data.keystroke` and
`key_events` are **not index-aligned** and feed **different models** — see the
docstring at `:385-404`. The first excludes auto-repeats and control keys
(`isKeystrokeApiKey` `:425-426`); the second is the complete record. Collapsing
them breaks the keystroke model.

### 3.5 `KeyData/KeyEventModel.kt` (119 lines)

`toCheckpointJson()` (`:53-77`) and `fromCheckpointJson()` (`:81-118`) spell
field names out explicitly **because R8 renames fields** and Gson reflection
would break in a minified build (see the comment at `:48-52`).

Protobuf solves this natively. Replace both if you convert the checkpoint;
leave them if you don't (§3.6).

### 3.6 `KeyData/SessionCheckpoint.kt` — recommend leaving on JSON

The crash-recovery store: `meta.json` (atomic tmp + rename) and `sensors.jsonl`
(append-only, fsynced **before** the meta rename, so a kill always leaves a
consistent pair — see the docstring at `:16-33`).

The design is sound and format-independent; a length-delimited protobuf journal
maps onto it directly. But this is device-local, never on a wire, and
converting it adds risk for zero gain.

**Recommendation: leave the checkpoint and the two debug payload sinks
(`saveDataLocally` `:1838`, `saveJsonDebugFile` `:1665`) on JSON.** Scope
protobuf to the wire.

If you do convert it, bump `FORMAT_VERSION` (`:181`) so an old checkpoint is
rejected as `format_mismatch` at `:122-123` rather than misparsed.

### 3.7 Host app — `TestTotpKTK`

The only coupling is `SaveCallback.onSaved(filePath: String, payload: String)`.
Four call sites:

| File | Line |
|---|---|
| `BehaviorBiometricActivity.kt` | 926-932 |
| `AddPayeeDetailsActivity.kt` | 537 |
| `AddNewPayeeAccountActivity.kt` | 676 |
| `PaymentActivity.kt` | 702 |

**None of them parse the payload** — they log it and pass a score along. So if
you keep the callback as a JSON string (render via `JsonFormat.printer()`), the
host app needs **zero changes**. Recommended.

---

## 4. DB backend — `Archive 1`

### 4.1 `requirements.txt`

Add pinned `protobuf`. Keep `brotli==1.1.0` and `zstandard==0.23.0`.

### 4.2 `utils/request_decompress.py` — the clean seam for W1

| Function | Line | Change |
|---|---|---|
| `read_request_bytes()` | 112-129 | **unchanged.** Already returns raw decompressed bytes with the zip-bomb cap (`MAX_DECOMPRESSED_BYTES`, `:18`) and magic-byte sniffing (`:104-109`). This is the seam |
| `get_request_json()` | 132-138 | add a sibling `get_request_proto(MessageClass)` doing `msg.ParseFromString(read_request_bytes())`, raising `RequestBodyError('Invalid protobuf', 400)`. **Keep `get_request_json()`** for dual-format |

### 4.3 `mobile_behaviour_api/behaviour_api.py` — the orchestrator

`CombinedMobileApi.post()` at `:86`:

- `:92` `get_request_json()` -> content-type dispatch
- `:95-107` reads `request_data['username']`, `['activity']`,
  `['behaviour_data']`, `['sessions']`, `.get('profile_type')`,
  `.get('session_id')`, `.get('android_id')`,
  `(first_session.get('device_info') or {}).get('device_id')` -> typed access
  with presence checks
- `:161-170` `payload_pattern` carries `sessions` through to the pattern core
- `:280` response `jsonify` — **keep JSON.** The SDK only reads
  `final_risk_score` / `risk_score` / `message`

**Do not touch**: the user guard (`:117`), the two-thread executor
(`:185-221`), the rollback logic (`:39-57`, `:238-253`), or the combined-risk
block (`:256-269`).

### 4.4 `mobile_pattern_svm_model_api/store_user_behaviour_data_svm_pattern.py` — the ingest

The heart of the DB write. Eleven mapping tables at `:21-112` are
`(column, payload_key, kind)` tuples driven by `source.get(key)`.

**Two approaches:**

| | Approach | Risk |
|---|---|---|
| **(a) recommended** | Add one proto -> dict adapter at the top of the module (honouring `optional` -> `None`). Then `_row_from_map` `:128`, `session_columns_values` `:184`, `validate_nav_payload` `:227`, `store_nav_sessions` `:282`, `iter_sensor_samples` `:153` all work **unchanged** | Low |
| **(b)** | Rewrite all eleven maps to read proto fields directly | 11 tables x ~40 fields of hand-mapping = high chance of a silent field drop |

Specific items either way:

- `_convert(value, kind)` `:115-125` — `kind='j'` does `json.dumps(value)`.
  **Keep JSON text for the CLOB columns** (§4.8)
- `validate_nav_payload()` `:227-279` — most type checks become redundant, but
  **keep the semantic rules**: `MAX_SESSIONS_PER_REQUEST` (`:236`),
  `session_type` required (`:249`), `NAV_SENSOR_TYPES` membership (`:273`), and
  above all the **accelerometer/gyroscope presence check at `:277`** — that is a
  business rule, not a type check
- `iter_sensor_samples()` `:153-169` — handles both wire shapes (flat list from
  the app, dict from DB read-back) and normalises `linear_accelerometer` ->
  `linear_acceleration`. **Keep both branches**
- `:377` `str(values_json)[:4000]` — **latent bug.** If `values` ever exceeds
  4000 chars the truncation produces invalid JSON, which `_json_col` then
  silently turns into `None`. Not currently reachable (pose_6dof's 15 doubles
  ~300 chars) but fix it during the migration
- `assign_owner()` `:176-181` mutates `sess['operator_id']` -> becomes
  `sess.operator_id = user_id` if protos flow this far

### 4.5 `mobile_pattern_svm_model_api/mobile_pattern_fetch_sessions_api.py` — W2

The most important file for the training CSVs.

| Function | Line | Change |
|---|---|---|
| `_num()` | 58-60 | **must map `None` -> unset, not -> 0.0** |
| `_nav_event()` | 90-98 | -> `NavigationEvent` |
| `_touch_event()` | 101-135 | -> `TouchEvent` |
| `_path_point()` | 138-149 | -> `PathPoint` |
| `_key_event()` | 152-173 | -> `KeyEvent`. Note the computed `dwell_ms` at `:161` |
| `_sensor_reading()` | 176-193 | -> `SensorSample`. `values` comes from `json.loads(VALUES_JSON)` at `:180` |
| `_session_dict()` | 229-299 | -> `Session`. The "same keys, same order" comments become moot — field numbers carry the contract. Genuine simplification |
| `_assemble_sessions()` | 302-311 | returns protos |
| `fetch_user_sessions()` | 375-410 | returns a proto `Data` |
| `MobilePatternFetchSessionsApi.get()` | 426-456 | `jsonify` at `:449` -> length-delimited proto stream; `Content-Type: application/x-protobuf`. **Keep `_authorised()` (`:413-423`) exactly as-is** |
| `payload_from_request_session()` | 319-368 | **highest-risk function in the migration** — see below |

**On `payload_from_request_session`**: its entire purpose is that "the predict
payload has exactly the same session shape as the training data" (module
docstring `:5-9`). It rebuilds the predict payload from the *request* session
using the same column maps and ordering as the DB read-back. **That symmetry
must survive the migration or predict and train diverge silently** — the exact
failure class the module was written to prevent.

**Do not touch**: `_load_children()` `:196-226` (the chunked child-table
queries), `_clob_as_text()` `:31-35`, or the paging/`OFFSET` logic at `:388-394`
(the comment records that a bind variable after OFFSET was rejected by the DB).

### 4.6 `utils/pattern_api_services.py` — W3 send

| Function | Line | Change |
|---|---|---|
| `_predict_body()` | 115-122 | `json.dumps(...).encode()` at `:117` -> `SerializeToString()`; `Content-Type: application/x-protobuf`. **Keep** the optional zstd layer (`:119-121`) |
| `call_predict_api()` | 125-152 | request body changes; **response stays JSON** — it is tiny (`is_genuine`, `risk_score`) and the validation at `:140-142` is worth keeping as-is |
| `call_train_api()` | 52-87 | `{user_id, profile_id, attempt}`. **Leave as JSON** — zero benefit |
| `get_train_status()` | 90-112 | **Leave as JSON** |
| `save_session_score()` | 155-199 | `DETAILS_JSON` CLOB (`json.dumps(ai)` at `:160`, truncated at `:161-162`). **Leave as JSON** |

### 4.7 `utils/authn_store.py` — R3 Celery

| Function | Line | Change |
|---|---|---|
| `pack()` | 32-34 | `base64(zlib(json.dumps(obj)))` -> `base64(SerializeToString())`. Still base64 because `celery_worker.py:21-23` pins `task_serializer='json'`. Protobuf is already compact — you can likely **drop the zlib layer** |
| `unpack()` | 37-38 | mirror |
| `store_pattern_authn()` | 50-54 | passes the unpacked sessions straight to `store_nav_sessions()`. **Works unchanged** with approach (a) in §4.4 |

**Do not touch** `dispatch()` `:116-128` — the "queue, else run inline" fallback
is what guarantees nothing is lost when Redis is down.

### 4.8 Oracle schema — the decision that saves you a migration

Four columns are format-coupled:

| Column | Table | Written at | Read at |
|---|---|---|---|
| `COORD_FRAME` | `NAV_SESSIONS` | `_convert(kind='j')` | `_json_col()` `:63-72` |
| `FIELDS_JSON` | `NAV_SESSIONS` | same | same |
| `SCREENS_JSON` | `NAV_SESSIONS` | same | same |
| `VALUES_JSON` | `NAV_SENSOR_SAMPLES` | `:373,377` | `:178-182` |

**Recommendation: keep all four as JSON text.** `_convert` becomes
`json.dumps(proto_to_dict(msg))`; `_json_col` keeps working unchanged.
**Zero `ALTER TABLE`, zero report breakage.** Protobuf bytes in BLOB would need
a migration, break any SQL/BI reading those columns, and these columns are
small — no win.

**All relational tables stay unchanged**: `NAV_SESSIONS`,
`NAV_NAVIGATION_EVENTS`, `NAV_TOUCH_EVENTS`, `NAV_TOUCH_PATH_POINTS`,
`NAV_KEY_EVENTS`, `NAV_SENSOR_SAMPLES`, `NAV_DEVICE_CAPABILITIES`,
`NAV_SESSION_SCORES`.

The only `ALTER TABLE` you need is **optional**, for §6.

### 4.9 `mobile_keystrokes_api/*` — W4, the external boundary

`mobile_core_api.py`:

- `:121-135` builds `corrected_behaviour_data` and `json.dumps`es it to
  `{ai_url}/mbkst-ai/api/v4/mobile_keystrokes/core/transform-data/`
- `:235` create-identity-profile payload
- `:418` user-authentication payload

**That AI service's code is in none of these repos.** Either it stays JSON (the
backend converts proto -> JSON for this one hop — easy, the block is tiny) or
you need a fourth team.

**Recommendation: keep W4 on JSON.**

Also leave as JSON:

- `store_user_behaviour_data.py:10` `feature_vectors_json`
- `store_user_behaviour_data.py:14` `json.dumps(behaviour_data)` — AES-encrypted
  via `get_encrypted_data()` in `utils/encrypt_decrypt.py:187-194`, decrypted by
  `decrypt_data_with_rsa_aes_encryption_v3_json()` at `:145-165`, and read by
  the dashboard
- `store_user_behaviour_data.py:35` `json.dumps(user_info)`
- `check_profile_exist_svm_pattern.py:11-18` `compact_device_details` ->
  `DEVICE_DETAILS` column

### 4.10 nginx

`nginx/default.conf:31` — `client_max_body_size 50m`. Fine as-is; protobuf
bodies shrink. `nginx/nginx.conf:24` has `gzip on` for responses. Just confirm
nothing upstream filters on content-type.

---

## 5. Out of scope — do not convert

| Area | Files | Why |
|---|---|---|
| Dashboard UAM | `adapid_dashboard/uam/**` (11 files) | small admin JSON; converting means rewriting the frontend |
| Silent TOTP | `silent_totp/**` (9 files) | unrelated to behavioural data |
| Dashboard behaviour reports | `dashboard_behaviour_api/**` (8 files) | read-only reporting over stored JSON |
| Reports | `adapid_reports/adapid_latest_files.py` | file listing |
| Status | `status_check/status_check.py` | health endpoint |

---

## 6. Data loss — current state, found while reading

### 6.1 The migration itself loses nothing, if you do three things

1. `optional` on every scalar (§2.1)
2. shortest-repr float conversion (§2.2)
3. preserve the `payload_from_request_session` <-> DB read-back symmetry (§4.5)

### 6.2 Pre-existing loss — the SDK collects these and the backend discards them

No column exists in any mapping table for the following. This is **unrelated to
protobuf** but the migration is the natural moment to fix it.

| Dropped | SDK source | Backend gap |
|---|---|---|
| `orientation_events[]` | `Keydata.kt:1567` | not in any map — **and the ML side reads it**: `new_adapid_schema.py:1054`, with the comment "exist in the app payload but the current GET response omits them" |
| `was_resumed`, `recovery_reason`, `resume_events[]` | `Keydata.kt:1539-1545` | not in `_SESSION_ROOT_MAP`. Partially survives via `screens[].process_restarts` inside `SCREENS_JSON` |
| `session_truncated`, `truncation_reason`, `truncated_at_ts`, `truncated_streams{}`, `dropped_pre_session_count`, `stream_first_sample_ts{}`, `batched_sample_count`, `clock_fallback_count`, `clock_fault_streams[]` | `buildSampling()` `:1359-1377` | `_SESSION_SAMPLING_MAP` has only 7 columns. **All nine flaw-10/18/56 diagnostics are lost** — the SDK comments say they exist "so a truncated session can be excluded", and nothing downstream can |
| `edge_distance_px`, `near_screen_edge`, `was_cancelled` (touch) | `buildTouchRecord()` `:916`, `buildCancelledTouchRecord()` `:1054` | not in `_TOUCH_MAP` |
| `edge_distance_px`, `near_screen_edge` (key) | `KeyStrokeManager.kt:469-470` | not in `_KEY_MAP` — the whole flaw-23 edge-rejection effort is collected and thrown away |
| `batched`, `clock_fallback` (per sample) | `addSample()` `:757-760` | not in `_SAMPLE_MAP` |

So the SDK does careful work to record *why* a session is untrustworthy, and
none of it reaches the model.

**Closing this** needs new nullable columns on `NAV_SESSIONS`,
`NAV_TOUCH_EVENTS`, `NAV_KEY_EVENTS`, `NAV_SENSOR_SAMPLES`, plus the matching
map entries and fetch-side builders. Follow the precedent in
`sdkfieldsschemachange.sql`, which did exactly this for `IS_REPEAT` /
`REJECTED`: nullable, no default, so older sessions leave them NULL.

**Keep it as a separate change from the protobuf migration.** Two changes at
once and you will not know which one moved your features.

### 6.3 Minor existing gaps

- `_SENSOR_CAP_MAP` expects `requested_hz` but the SDK never sends it (it sends
  `req_hz` per sample) — that column is always NULL
- `_AXIS_CAP_MAP` expects `supported` but `buildDeviceInfo` `:1260-1269` does not
  send it — always NULL

---

## 7. Dual-format rollout — nothing breaks during the migration

**Do not remove JSON.** Add protobuf beside it.

Each endpoint dispatches on `Content-Type` / `Accept`:

| Endpoint | Protobuf when | Else |
|---|---|---|
| `POST /api/v4/combined_behaviour_api` | `Content-Type: application/x-protobuf` | current JSON path, untouched |
| `GET /nav/back/api/v1/behavioral/sessions/<id>` | `Accept: application/x-protobuf` | current `jsonify` |
| `POST /nav/ai/predict` | `Content-Type: application/x-protobuf` | current `_extract_payload` branches |

Both paths converge immediately after the parse seam — the adapter in §4.4(a),
`read_user_file` on the ML side — so the JSON path keeps working byte-identically
while protobuf rolls out one hop at a time.

The SDK already retries plain on HTTP 415 when a `Content-Encoding` is rejected
(`Keydata.kt:1757-1760`). Extend that pattern to content-type, and the SDK
degrades safely against an old backend.

**Costs of dual-format**: two codecs to maintain until JSON is dropped, and the
parity harness is the only thing proving they produce identical output. Without
it, dual-format just hides divergence.

---

## 8. Order of work

1. Write `adapid_behaviour_v1.proto`, generate both languages, **freeze field
   numbers**. (~1 day)
2. **Build the round-trip parity harness before touching any production path.**
   The 44 captured payloads in `Archive 1/New folder/*/` are the corpus:
   JSON -> proto -> JSON, assert byte-equal modulo key order. This is what
   catches §2.2 and every missed `optional`. Non-negotiable.
3. **W2 + the ML staging file first** (fetch API -> envelope -> CSV). Largest
   payload, and verifiable offline. Rebuild a bundle and diff the training CSV
   column-for-column.
4. **W3** (predict). Verify the `payload_from_request_session` symmetry.
5. **W1** (SDK upload). Last — needs a coordinated app release.
6. Leave W4, R1, R2, R3, R5 on JSON.

---

## 9. Effort

| Piece | Estimate |
|---|---|
| Schema + codegen + parity harness | 2-3 days |
| ML side (see the other doc) | 2-3 days |
| DB backend, approach (a) | 4-5 days |
| DB backend, approach (b) | 8-10 days |
| SDK, option (a) on `SensorDataCollector` | ~1 week |
| SDK, option (b) | ~3 days |
| Testing / parity | budget as much as the implementation |

**Before committing to any of it**: profile. If the Oracle multi-join in
`_load_children` or the numpy feature math dominates your latency, this
migration moves a number that is not your bottleneck. The strongest arguments
for doing it anyway are the ~90 MB W2 pages, mobile upload size, and replacing
the "same keys, same order" comments with a real schema contract — not raw
parse speed.
