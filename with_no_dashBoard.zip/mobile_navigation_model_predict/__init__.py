"""POST /nav/ai/predict - score one behavioural session."""
