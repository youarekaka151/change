"""
Route for the mobile navigation prediction API
"""
from flask import Blueprint

from mobile_navigation_model_predict.mobile_navigation_predict import MobileNavigationPredict

mobile_navigation_predict_api = Blueprint('mobile_navigation_predict_api', __name__)

mobile_navigation_predict_api_view = MobileNavigationPredict.as_view('mobile_navigation_predict')
mobile_navigation_predict_api.add_url_rule("/nav/ai/predict", view_func=mobile_navigation_predict_api_view, methods=['POST', ])
