"""
Score one stored session against that user's One-Class SVM

NAV posts the session as the bare JSON body, with no envelope and no auth
header, and requires HTTP 200 + status == 'success' + the key `is_genuine`
before it records a verdict. Anything else it reads as "no verdict", which is
the correct reading of a failure and is why no error path here invents one.
"""

from flask import jsonify, request
from flask.views import MethodView

from common import service_registry
from common.responses import service_unavailable
import zstandard
import json

def _extract_payload():
    """
    Extracts and parses the request JSON payload.
    Supports both uncompressed JSON and zstd-compressed payloads.
    Returns parsed dict/list, or None if parsing fails.
    """
    encoding = request.headers.get('Content-Encoding', '').strip().lower()
 
    if encoding == 'zstd':
        try:
            raw_data = request.get_data()
            if not raw_data:
                return None
            dctx = zstandard.ZstdDecompressor()
            decompressed_data = dctx.decompress(raw_data)
            return json.loads(decompressed_data.decode('utf-8'))
        except (zstandard.ZstdError, json.JSONDecodeError, UnicodeDecodeError, ValueError):
            return None
 
    # Fallback for standard/uncompressed JSON requests
    return request.get_json(silent=True)

class MobileNavigationPredict(MethodView):
    """POST /nav/ai/predict"""

    def post(self):
        if service_registry.prediction_service is None:
            return service_unavailable('Model service unavailable')

        # silent=True so a malformed body becomes our own 400 with a readable
        # message instead of Flask's HTML 400 page, which NAV would record as
        # ml_http_400 with nothing to act on.
        # payload = request.get_json(silent=True)
        # Extracts payload (handles both regular JSON and zstd compressed)
        payload = _extract_payload()

        result = service_registry.prediction_service.predict(payload)

        # predict() returns a plain dict on success and (body, status) on
        # failure. jsonify() on the tuple would serialise it as a JSON ARRAY
        # with HTTP 200, so the caller would see a 200 wrapping an error.
        if isinstance(result, tuple):
            body, status_code = result
            return jsonify(body), status_code
        return jsonify(result)
