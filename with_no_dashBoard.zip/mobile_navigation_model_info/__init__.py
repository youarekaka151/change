"""GET /nav/ai/info - what is actually deployed."""
