"""
Introspection: selection, extractor version, loaded bundles
"""

from flask import jsonify
from flask.views import MethodView

from common import service_registry
from common.responses import service_unavailable

from mobile_navigation_core import selections

class MobileNavigationInfo(MethodView):
    """GET /nav/ai/info"""

    def get(self):
        if service_registry.prediction_service is None:
            return service_unavailable()
        body = service_registry.prediction_service.info()
        body['selection'] = selections.describe()
        return jsonify(body), 200
