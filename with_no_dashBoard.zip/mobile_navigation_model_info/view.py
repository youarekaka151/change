"""
Route for the mobile navigation model info API
"""
from flask import Blueprint

from mobile_navigation_model_info.mobile_navigation_info import MobileNavigationInfo

mobile_navigation_model_info_api = Blueprint('mobile_navigation_model_info_api', __name__)

mobile_navigation_model_info_api_view = MobileNavigationInfo.as_view('mobile_navigation_model_info')
mobile_navigation_model_info_api.add_url_rule("/nav/ai/info", view_func=mobile_navigation_model_info_api_view, methods=['GET', ])
