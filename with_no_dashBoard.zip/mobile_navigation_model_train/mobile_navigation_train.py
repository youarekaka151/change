"""
Queue a first enrolment - this route never trains

It writes a few small JSON files into the job spool and returns; train_jobs.py's
own process (its own supervisord program) does the training, because that takes
minutes and a gunicorn request has 180 s.
"""

import logging

# `common` first: importing it puts the project root on sys.path, which is what
# makes the `train_jobs` import below resolvable.
from common import service_registry
from common.responses import (deployed, service_unavailable, train_auth_error,
                              train_state)

import train_jobs

from flask import jsonify, request
from flask.views import MethodView

logger = logging.getLogger(__name__)


class MobileNavigationModelTrain(MethodView):
    """POST /nav/ai/train - 200 ready | 202 queued/running | 4xx/5xx."""

    def post(self):
        denied = train_auth_error()
        if denied:
            return denied
        if service_registry.prediction_service is None:
            return service_unavailable()

        body = request.get_json(silent=True) or {}
        user_id = body.get('user_id')
        profile_id = body.get('profile_id')
        attempt = body.get('attempt')
        if not train_jobs.valid_user_id(user_id):
            return jsonify({'status': 'error', 'message': 'invalid user_id'}), 400
        if attempt is not None and (not isinstance(attempt, str) or len(attempt) > 100):
            return jsonify({'status': 'error', 'message': 'invalid attempt'}), 400

        # A bundle is never overwritten, so an existing one is the answer.
        bundle, error = deployed(user_id)
        if error:
            logger.error('train %s: bundle exists but does not load: %s',
                         user_id, error)
            return jsonify({'status': 'error', 'message': 'bundle exists but does '
                            'not load', 'reason': error}), 500
        if bundle is not None:
            recorded = (bundle.provenance or {}).get('profile_id')
            # Legacy research bundles record no profile_id.
            if recorded is not None and profile_id is not None \
                    and str(recorded) != str(profile_id):
                return jsonify({'status': 'error', 'message': 'bundle belongs to '
                                'profile %s, not %s' % (recorded, profile_id)}), 409
            return jsonify(train_state(
                user_id, 'ready', {'attempt': attempt},
                built_at=(bundle.provenance or {}).get('built_at'))), 200

        record = train_jobs.enqueue(user_id, profile_id=profile_id, attempt=attempt)
        return jsonify(train_state(user_id, record.get('state'), record)), 202
