"""POST /nav/ai/train - queue a first enrolment."""
