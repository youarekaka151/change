"""
Route for the mobile navigation model training API
"""
from flask import Blueprint

from mobile_navigation_model_train.mobile_navigation_train import MobileNavigationModelTrain

mobile_navigation_model_train_api = Blueprint('mobile_navigation_model_train_api', __name__)

mobile_navigation_model_train_api_view = MobileNavigationModelTrain.as_view('mobile_navigation_model_train')
mobile_navigation_model_train_api.add_url_rule("/nav/ai/train", view_func=mobile_navigation_model_train_api_view, methods=['POST', ])
