"""
Report how a queued enrolment went

NAV calls this on each later upload until the job is done, so it must stay
cheap: it reads the job spool's status file and, at most, loads the user's
bundle to confirm it is really on disk.
"""

# `common` first: importing it puts the project root on sys.path, which is what
# makes the `train_jobs` import below resolvable.
from common import service_registry
from common.responses import (deployed, service_unavailable, train_auth_error,
                              train_state)

import train_jobs

from flask import jsonify, request
from flask.views import MethodView


class MobileNavigationModelTrainStatus(MethodView):
    """GET /nav/ai/train/<user_id> - ready | queued | running | failed | none."""

    def get(self, user_id):
        denied = train_auth_error()
        if denied:
            return denied
        if service_registry.prediction_service is None:
            return service_unavailable()
        if not train_jobs.valid_user_id(user_id):
            return jsonify({'status': 'error', 'message': 'invalid user_id'}), 400

        record = train_jobs.status(user_id) or {}
        bundle, error = deployed(user_id)
        if bundle is not None:
            recorded = (bundle.provenance or {}).get('profile_id')
            asked = request.args.get('profile_id')
            # Same rule as POST: a bundle recorded for another profile is not
            # this user's model (legacy research bundles record none).
            if recorded is not None and asked and str(recorded) != asked:
                return jsonify(train_state(user_id, 'failed', record,
                                           reason='error:profile_mismatch')), 200
            return jsonify(train_state(
                user_id, 'ready', record,
                built_at=(bundle.provenance or {}).get('built_at'))), 200
        if error:
            return jsonify(train_state(
                user_id, 'failed', record,
                reason='error:bundle_unloadable: %s' % error)), 200
        if not record:
            return jsonify(train_state(user_id, 'none')), 200

        state = record.get('state')
        # "ready" in the status file with no bundle on disk means the bundle was
        # removed (a manual retrain): report it as never trained.
        if state == 'ready':
            state = 'none'
        return jsonify(train_state(user_id, state, record)), 200
