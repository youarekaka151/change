"""GET /nav/ai/train/<user_id> - how the enrolment went."""
