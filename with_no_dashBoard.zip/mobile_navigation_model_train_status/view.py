"""
Route for the mobile navigation model training status API
"""
from flask import Blueprint

from mobile_navigation_model_train_status.mobile_navigation_train_status import MobileNavigationModelTrainStatus

mobile_navigation_model_train_status_api = Blueprint('mobile_navigation_model_train_status_api', __name__)

mobile_navigation_model_train_status_api_view = MobileNavigationModelTrainStatus.as_view('mobile_navigation_model_train_status')
mobile_navigation_model_train_status_api.add_url_rule("/nav/ai/train/<user_id>", view_func=mobile_navigation_model_train_status_api_view, methods=['GET', ])
