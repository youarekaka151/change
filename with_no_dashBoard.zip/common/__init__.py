"""Shared setup for the API layer.

Importing this package makes the ML engine importable: it puts the application
root (the folder holding app.py and train_jobs.py) on sys.path and then imports
mobile_navigation_core, which in turn puts its own directory there. After that
the views can `import selections`, `import prediction_service` and so on by
plain name, whichever directory the process was started from.
"""

import os
import sys

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))     # .../Structure_code/common
APP_ROOT = os.path.dirname(PACKAGE_DIR)                      # .../Structure_code

if APP_ROOT not in sys.path:
    sys.path.insert(0, APP_ROOT)

import mobile_navigation_core                                # noqa: E402,F401
