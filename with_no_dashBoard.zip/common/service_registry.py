"""The one PredictionService every view scores against.

Built at import so gunicorn's preload_app=True pays the cost once in the master
and the workers inherit it copy-on-write. A failure is kept as `startup_error`
rather than re-raised: a process that exits at import gives the operator a stack
trace in a log, while one that answers 503 with the reason gives them the reason
at the URL they are already probing.

Views read `service_registry.prediction_service` through the module rather than
importing the name, so they see whatever this module holds instead of a copy
taken at their own import time.
"""

import logging

import selections


logger = logging.getLogger(__name__)

prediction_service = None
startup_error = None

try:
    from prediction_service import PredictionService

    _selection = selections.active()
    prediction_service = PredictionService(
        models_dir=selections.models_dir(),
        templates_dir=selections.templates_dir(),
    )
    logger.info('PredictionService ready: selection %s%s (%s), models %s',
                _selection['name'],
                ' [experimental]' if _selection['experimental'] else '',
                _selection['file'], prediction_service.models_dir)
except Exception as error:                              # noqa: BLE001
    startup_error = str(error)
    logger.critical('PredictionService did NOT start: %s', error)
