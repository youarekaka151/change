"""Response helpers used by more than one view.

The bodies here are part of the endpoint contract NAV reads, so their keys and
wording must not drift. NAV requires HTTP 200 + status == 'success' + the key
`is_genuine` before it records a verdict; anything else it reads as "no
verdict", which is why no helper here ever invents one.
"""

import hmac
import os

from flask import jsonify, request

from common import service_registry


def service_unavailable(message='model service unavailable'):
    """The 503 every view returns when PredictionService did not start.

    `message` is a parameter because /nav/ai/predict has always answered with a
    capitalised 'Model service unavailable' while the others use lower case.
    """
    return jsonify({'status': 'error', 'message': message,
                    'reason': (service_registry.startup_error or '')[:500]}), 503


def train_auth_error():
    """None when X-ML-Train-Key matches, else the (body, status) to return.

    NAV reaches this service from a separate container whose address is not
    fixed, so an nginx IP allow-list cannot guard the enrolment routes. With the
    key unset they refuse rather than run open.
    """
    expected = os.getenv('ML_TRAIN_KEY') or ''
    if not expected:
        return jsonify({'status': 'error',
                        'message': 'training is not configured (ML_TRAIN_KEY)'}), 503
    provided = request.headers.get('X-ML-Train-Key') or ''
    # Bytes: compare_digest raises TypeError on a non-ASCII str.
    if not hmac.compare_digest(provided.encode('utf-8'), expected.encode('utf-8')):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    return None


_FRIENDLY_REASON_PREFIXES = {
    'nav_rejected:nav_no_profile':
        'This user has never been enrolled - no profile found in NAV.',
}


def _friendly_reason(reason):
    """A human-readable sentence for a known `reason` prefix, else None."""
    if not reason:
        return None
    for prefix, text in _FRIENDLY_REASON_PREFIXES.items():
        if reason.startswith(prefix):
            return text
    return None


def train_state(user_id, state, record=None, **extra):
    """The body both enrolment routes answer with."""
    record = record or {}
    reason = record.get('reason')
    body = {'status': 'success', 'user_id': user_id, 'state': state,
            'attempt': record.get('attempt'), 'reason': reason,
            'message': _friendly_reason(reason),
            'built_at': record.get('built_at')}
    body.update(extra)
    return body


def deployed(user_id):
    """(bundle, None) if the user has a loadable bundle, (None, None) if none,
    (None, error) if one exists but does not load."""
    from bundle_loader import ArtifactError
    from feature_extraction import ExtractionError

    store = service_registry.prediction_service.store
    if not os.path.exists(store.bundle_path(user_id)):
        return None, None
    try:
        bundle, _ = store.get(user_id)
        return bundle, None
    except (ArtifactError, ExtractionError, OSError) as error:
        return None, str(error)[:300]
