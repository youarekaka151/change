# Protobuf migration — ML side (`docker-compose`)

Scope: the ADAPID ML prediction/enrolment service only. The SDK and DB-backend
changes are in `PROTOBUF_MIGRATION_SDK_BACKEND.md`.

Every file:line reference below was read directly from this tree. Nothing here
is inferred from naming.

---

## 1. Summary

The ML service touches behavioural data at **four** places. Everything else —
feature extraction, DTW templates, the sanitizer, the trainer, CSV writing — is
format-agnostic and needs **no change at all**.

| Entry point | What it reads | File |
|---|---|---|
| W2 fetch (training data) | HTTP body from the backend | `enrollment_service.py:339` |
| Staging envelope — reader 1 | `sessions.json` on disk | `vendor/new_adapid_schema.py:1572` |
| Staging envelope — reader 2 | the same file, streamed | `vendor/behavior_cleaner.py:203-282` |
| W3 predict | HTTP body from the backend | `mobile_navigation_model_predict/mobile_navigation_predict.py:18-38` |

The chain is:

```
NavFetch._get()                 json.loads(body)          <- change A1
  -> EnvelopeWriter.add()       json.dumps(session)       <- change A3
     -> sessions.json
        -> read_user_file()     json.load(f)              <- change A5
           -> load_views() -> SessionView -> extractor -> to_csv   (NO CHANGE)
        -> SessionStream        regex + raw_decode        <- change A6
           -> build_census() / availability_totals()              (NO CHANGE)
```

There are **two independent readers of the same staging file**. Changing only
one causes enrolment to fail *after* a successful multi-page fetch.

---

## 2. Cross-cutting constraints (decide these before writing code)

### 2.1 `optional` on every scalar — correctness, not style

proto3 scalars cannot distinguish "absent" from `0` / `""` / `false`. This code
depends on that distinction:

- `new_adapid_schema._f()` / `_i()` turn a missing numeric into `np.nan`.
- `np.nan` drives the `*_measurable` flags and `cap_*` capability detection.
- `enrollment_service.py:472-476` **refuses the whole enrolment** on a
  non-finite feature (`features_non_finite`).
- `enrollment_service.py:480-484` refuses on a constant feature
  (`features_constant`).

A NULL silently arriving as `0.0` changes feature values and can flip a refusal
gate. Use proto3 field presence (`optional`, protobuf >= 3.15) on every scalar
and map `not msg.HasField('x')` -> Python `None`.

### 2.2 Float precision — this will silently change your training data

Today's path is **not** a plain float32 widening:

| Step | Value |
|---|---|
| Kotlin `Float` | `0.1f` |
| Gson writes shortest round-trip text | `"0.1"` |
| Python `json.loads` | float64 `0.1` |
| Oracle `NUMBER` (decimal) | exactly `0.1` |
| A proto `double` carrying `0.1f` widened | `0.10000000149011612` |

Options:

1. Keep proto `double` and have the **SDK** convert via shortest-repr round-trip
   (`value.toString().toDouble()`). Values stay bit-identical to today.
2. Accept the change and re-verify every feature against the stored CSVs.

Option 1 is the no-data-change choice. See the SDK doc for where this applies.

### 2.3 The envelope must be length-delimited

`NavFetch` pages 10 sessions at a time because one page with events is
**~90 MB** (`enrollment_service.py:115`), and `EnvelopeWriter` streams
session-by-session so "a user's whole history is never held in memory here"
(class docstring, `:413-423`).

Protobuf parsing is all-or-nothing per message, with a 2 GB hard limit. A single
message holding a user's full history breaks that property.

- **W2 response**: keep paging at 10 and parse each bounded page, *or* emit a
  varint length-delimited stream of `Session`.
- **Staging file**: **must** be varint length-delimited so both readers can
  stream one session at a time.

---

## 3. Group A — required data-path changes

### A1. `enrollment_service.py:328-354` — `NavFetch._get()`

**Current**

```python
with urllib.request.urlopen(request, timeout=READ_TIMEOUT_S) as resp:
    body = resp.read()
return json.loads(body)
```

**Change**

- Parse the bytes into `SessionsResponse` (or a length-delimited `Session`
  stream).
- Request header at `:331` — `Accept: application/x-protobuf`.
- The `except (OSError, http.client.HTTPException, ValueError)` branch at `:349`
  currently catches a truncated/non-JSON body via `ValueError`. **Add protobuf
  `DecodeError`** or a truncated page becomes an uncaught exception instead of a
  retry.

**Keep unchanged**: `PAGE_ATTEMPTS`, `RETRY_STATUS`, the jittered backoff at
`:335`, and the `401/403 -> Retryable('nav_auth')` branch at `:344-347`.

**Why**: this is where all training data enters the service, and it is the
largest payload in the system.

**Effect**: the single biggest latency/bandwidth win on the ML side.

---

### A2. `enrollment_service.py:356-406` — `NavFetch.sessions()`

**Current** — validates JSON shape:

```python
data = body.get('data') if isinstance(body, dict) else None
if body.get('success') is not True or not isinstance(data, dict) \
        or not isinstance(data.get('sessions'), list):
    raise FetchError('nav_bad_envelope at offset %d' % offset)
```

**Change**: typed field access with presence checks.

**Keep every semantic guard** — protobuf removes *shape* risk, not these:

| Line | Guard | Why it must stay |
|---|---|---|
| `:369-370` | profile present with an id | no profile = nothing to train |
| `:372-374` | `profile.user_id == self.user_id` | wrong user's data |
| `:379-380` | `nav_profile_changed` mid-fetch | pages from two different profiles |
| `:388-390` | every session has a `session_id` | it keys the DTW lookup and CSV rows (`new_adapid_schema.py:1630-1676`) |
| `:399-401` | page guard | runaway paging |
| `:404-406` | `n_collected < total` | **training on partial history** |

---

### A3. `enrollment_service.py:413-448` — `EnvelopeWriter`

**Current** — hand-written JSON text:

```python
self._fh.write('{"data": {"sessions": [')        # :429
self._fh.write(json.dumps(session))              # :433
self._fh.write(json.dumps(tail)[1:])             # :441  string surgery
```

`sessions` is deliberately the **first** key so `SessionStream` finds the right
array (see the docstring at `:418-422`).

**Change**: replace with a varint length-delimited protobuf writer producing
`sessions.pb`. Keep `add()` / `close()` / `abort()` signatures so
`enrollment_service.enrol()` at `:876-893` is unaffected.

The envelope *tail* (`user_id`, `profile`, `total_sessions`,
`returned_sessions`, `include_events`) is needed by `sessions_from_blob` for
`meta`. Either write it as a separate sidecar message or prepend a single
header record before the session stream.

**Effect**: the first-key ordering hack, the `[1:]` string surgery and the
hand-built envelope all disappear. This code gets materially simpler.

---

### A4. `enrollment_service.py:111` — `ENVELOPE_NAME`

```python
ENVELOPE_NAME = 'sessions.json'     # a fixed name, never the raw user id
```

-> `'sessions.pb'`. Keep the comment; the "never the raw user id" property still
matters.

---

### A5. `vendor/new_adapid_schema.py:1572-1588` — `read_user_file()`

**This is the only `json.load` in the entire feature / DTW / CSV pipeline.**

**Current**

```python
def read_user_file(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        blob = json.load(f)
    return sessions_from_blob(blob, fallback_user=os.path.splitext(
        os.path.basename(path))[0])
```

**Change** — dispatch on extension:

```python
def read_user_file(path):
    if path.endswith('.pb'):
        return read_user_file_pb(path)       # -> (list[dict], meta)
    with open(path, 'r', encoding='utf-8-sig') as f:
        blob = json.load(f)
    return sessions_from_blob(blob, fallback_user=...)
```

`read_user_file_pb` must return the **same** `(sessions_raw, meta)` contract:
a list of plain dicts and a meta dict with `user_id`, `profile_type`,
`total_sessions`, `source`.

**Why extension dispatch rather than replacement**: the `.json` path stays
byte-identical, so archived research dumps keep loading and the parity baseline
survives. This also satisfies "don't disturb the working one".

**What this unlocks for free** — every consumer below reaches the file only
through this function:

- `load_views()` at `:1682` -> `:1693`
- `new_build_dtw_templates.build_for_user()` -> `load_views()` at `:1170`
- `new_feature_creation_session.SessionPipeline.run()` -> `load_views()` at
  `:3779`
- `new_feature_creation_session_v2.SessionPipelineV2` inherits `run()` from V1
  (`_v2.py:3084-3094`)

`sessions_from_blob()` at `:1591-1627` handles four historical envelope shapes
(v3 backend / v2 nested / app payload / bare list). With one proto schema these
collapse to one — but keep the function for archived `.json` files.

---

### A6. `vendor/behavior_cleaner.py:200-282` — `SessionStream` / `iter_raw_sessions`

**The reader people miss.** Not reached via `read_user_file`.

**Current** — a hand-rolled streaming JSON parser:

```python
_SESSIONS_RE = re.compile(r'"sessions"\s*:\s*\[')     # :200
...
dec = json.JSONDecoder()                              # :233
m = _SESSIONS_RE.search(buf)                          # :240
self.head = buf[:m.end()]                             # :247
obj, end = dec.raw_decode(buf)                         # :268
```

It also captures `head` / `tail` / `eol` verbatim so the research CLI can write
a cleaned copy without losing the envelope, and raises `NotASessionDump` when
the pattern is not found.

**Used by**:

- `enrollment_service.availability_totals()` — `:492`
- the `BC.build_census(...)` call in `build_bundle()` — `:639`

**Change**: add a length-delimited protobuf branch, dispatching on extension the
same way as A5. The `head`/`tail`/`eol` machinery is only needed by the
research CLI writer at `:1163-1233`; the protobuf branch does not need it.

**If you skip this**: enrolment fetches all pages successfully, writes
`sessions.pb`, then dies in `availability_totals()` with `NotASessionDump`.

**Effect**: the regex, sliding buffer, head/tail capture and `NotASessionDump`
failure mode all become unnecessary on the protobuf path, while keeping
one-session-at-a-time memory.

---

### A7. `mobile_navigation_model_predict/mobile_navigation_predict.py:18-38`

**Current** — `_extract_payload()`:

```python
encoding = request.headers.get('Content-Encoding', '').strip().lower()
if encoding == 'zstd':
    ... json.loads(decompressed_data.decode('utf-8'))
return request.get_json(silent=True)
```

**Change**: add a branch on `Content-Type: application/x-protobuf`, parsing
`request.get_data()`. **Keep both JSON branches** so an old backend still works.

**Must still return `None` on failure** — `predict()` relies on that to emit its
own readable 400 instead of Flask's HTML 400 page, which NAV would record as
`ml_http_400` with nothing actionable (see the docstring at `:47-49`).

---

### A8. `mobile_navigation_core/prediction_service.py:126-143` — `_unwrap()`

**Current**: accepts either a bare session dict or a `{user_id, sessions:[...]}`
batch — the backend posts the former, a human testing by hand posts the latter.

**Change**: typed equivalent, or convert proto -> dict before calling it.

Everything after `_unwrap` is untouched: `extract_session`, the quality gate at
`:225-230`, `bundle.score`, `calculate_risk_score`, and the response dict at
`:251-274`.

---

## 4. Group B — supporting changes

### B1. `requirements.txt`

Add `protobuf==<exact version>`. The file header explains why every line is
pinned (Gap 10: unpinned deps silently unpickled models across versions).

### B2. `mobile_navigation_core/boot_checks.py:58-59`

```python
CHECKED_PACKAGES = ('numpy', 'pandas', 'scipy', 'scikit-learn', 'tslearn',
                    'joblib', 'PyWavelets', 'allantools')
```

Add `'protobuf'`. Do **not** add it to `HARD_VERSION_PACKAGES` at `:63` — that
list is for packages that own the pickles (scikit-learn). A protobuf mismatch
should warn, not refuse boot.

`_pinned_versions()` at `:156-169` reads `name==version` lines from
`requirements.txt`, so B1 is a prerequisite.

### B3. Put generated stubs in a new `mobile_navigation_core/proto/`, not `vendor/`

`vendor/` is documented as "a verbatim copy of the research pipeline"
(`boot_checks.py:12-14`, `enrollment_service.py:3-13`).
`_check_vendor` at `:103-120` counts `.py` files there and reports `n_files` in
the boot log — it is **logged, not asserted**, so extra files will not fail the
boot, but they destroy the verbatim invariant the parity story rests on.

### B4. A5 and A6 edit vendored files — keep the diff minimal

These are the only two `vendor/` files that must change. Keep each edit to
extension dispatch (~5 lines) so the `.json` code path is byte-identical. Then
"same CSV from the same archived dump" is still provable after the change —
which is the test that matters.

Record the divergence wherever you track vendor provenance.

Note: `enrollment_service.trainer_sha256()` at `:168-170` hashes
`new_train_session.py` only, so these two edits do **not** change any bundle's
`trainer_sha256`. Do not touch `new_train_session.py` or every bundle's
provenance hash changes.

### B5. `mobile_navigation_core/feature_extraction.py:210` — preserve the deepcopy contract

```python
raw = copy.deepcopy(raw_session)             # see the docstring
```

Both `BC.clean_session` and `SAN.sanitize_view` repair **in place**, reaching
into nested `key_events` / `touch_events` / per-sensor arrays. The docstring at
`:179-185` records that a shallow copy already caused a double-sanitised second
reading in the first parity test.

If protos ever flow past the parse seam, the same hazard applies. 167 ms on a
3.5 MB session against 9-17 s of extraction — the copy is cheap.

### B6. `feature_extraction.py:109-159` — `normalize_upload_shape()`

Regroups a flat `sensor_samples` list into the dict-keyed shape and fills
`down_size` / `point_size` / `seq`. **Logic unchanged** — it operates on whatever
dict you hand it.

Only verify the decoder produces the same flat-list shape the app sends:
`behavior_cleaner` indexes `sensor_samples` by sensor name and **crashes** on a
flat list (`:122`). This one fails loudly, which is the good case — but cover it
with a test.

---

## 5. Group C — explicitly unchanged, and why that is guaranteed

| Component | Size | Why it cannot be affected |
|---|---|---|
| `vendor/new_feature_creation_session.py` | 4,208 | Zero JSON in the data path. Consumes `SessionView`. Reaches the file only via A5 (`:3779`) |
| `vendor/new_feature_creation_session_v2.py` | 3,416 | `SessionPipelineV2` inherits `run()` from V1 (`:3084-3094`) |
| `vendor/new_feature_registry.py` | 964 | Column bucketing by name. `json.load` at `:953` is a selection file (config) |
| `vendor/derived_features.py` | 694 | Pure computation |
| `vendor/keystroke_fields.py` | 525 | Pure computation |
| `vendor/new_build_dtw_templates.py` | 1,330 | One coupling: `load_views(path)` at `:1170` -> A5 |
| `vendor/new_sensor_sanitizer.py` | 886 | Imports only `numpy` and `new_adapid_schema`. No JSON at all |
| `vendor/payload_canonicalizer.py` | 1,844 | `canonicalize_session(dict)`. The `json.load`s at `:1731` / `:1772` are the `explain` / `validate` CLIs only |
| `vendor/new_train_session.py` | 1,272 | Reads CSVs + selection files. **Hashed by `trainer_sha256()` — do not touch** |
| CSV writing | — | `train_df.to_csv` / `test_df.to_csv` at `new_feature_creation_session.py:3853-3854`, on a DataFrame |
| `SessionView` | — | `__init__` at `new_adapid_schema.py:970` reads plain dicts via `.get()` with `_s`/`_i`/`_f`. `_iter_sensor_streams` at `:1076` already handles **both** sensor_samples shapes — keep both branches |
| Selection / config files | — | `features/selections.json`, `features/v3/selected_rev4.json`, `selections.py:137`, `package_ml_bundle.py:108`, `new_feature_registry.py:953`, `new_train_session.py:228,251`. Human-edited. `feature_set_sha256` hashes column **names**, so bundle certification is format-independent |
| Job state | — | `train_jobs.py:99,108`. Internal state, no size or latency pressure |
| Bundles | — | `*_ocsvm.joblib`, `*_dtw_templates.pkl`. joblib/pickle, untouched |
| All 5 HTTP responses | — | `predict`, `train`, `train/<id>`, `health`, `info` — small `jsonify` bodies. Keep JSON; NAV already parses them and protobuf gains nothing |

---

## 6. Order of work

1. **Build the parity harness first**, before changing any production path.
   There is **no `tests/` directory in this tree** — `tests/test_enrollment_parity.py`
   is cited in `enrollment_service.py:14` but does not exist here, and the
   docstring notes it needs the archived research data. Since everything routes
   through A5, this harness is the highest-value thing to write.
   - Take an existing `.json` dump -> build bundle -> record the training CSV.
   - Convert the same dump to `.pb` -> build bundle -> **diff the CSV
     column-for-column.** Any non-zero diff means §2.1 or §2.2 is wrong.
2. A5 + A6 (the two file readers) with extension dispatch. Verify with step 1.
3. A3 + A4 (the writer). Now the whole staging path is protobuf end to end.
4. A1 + A2 (the fetch). Needs the backend's W2 side ready.
5. A7 + A8 (predict). Needs the backend's W3 side ready.
6. B1-B6 alongside.

Steps 2-3 can be done and validated **entirely locally**, with no backend
changes at all, because extension dispatch means you can hand-convert a dump
and run enrolment on it. Do that first — it de-risks everything else.

---

## 7. Risks, in order of severity

1. **Float precision (§2.2)** — silently shifts every feature value. No error,
   no warning; your models just drift. Only the parity harness catches it.
2. **Missing A6** — enrolment crashes *after* a successful multi-page fetch,
   which looks like a fetch bug and isn't.
3. **Field presence (§2.1)** — a NULL arriving as `0.0` can flip the
   `features_non_finite` or `features_constant` refusal gates at
   `enrollment_service.py:472-484`, turning a healthy user into a refused
   enrolment or vice versa.
4. **Editing two vendored files (B4)** — weakens the research-parity invariant
   unless the `.json` path stays byte-identical.
5. **Single-message envelope (§2.3)** — reintroduces the memory blow-up that
   `EnvelopeWriter` and `SessionStream` were both written to avoid.

---

## 8. What you actually get

**Gains**: W2 is ~90 MB per page of text parsing replaced by binary — the one
place on the ML side with real measurable headroom. A3 and A6 delete genuinely
fragile code (a hand-built JSON envelope with string surgery, and a
regex-driven streaming parser). Field presence replaces null-purging
conventions with a schema guarantee.

**Not gained**: nothing in feature extraction, DTW, the sanitizer or the trainer
gets faster — those are CPU-bound on numpy, not on parsing. If profiling shows
the Oracle multi-join in `_load_children` or the feature math dominates your
latency, this migration moves a number that is not your bottleneck. Profile
before committing.
