"""Enrolment job spool, and the trainer process that drains it.

Two halves, one file:

  enqueue() / status()   called by app.py inside gunicorn. Cheap: a few small
                         JSON files, no model code imported.
  main()                 the trainer, run by supervisord as its own program
                         ([program:trainer] in nginx/supervisord.conf). It is the
                         only process that ever trains. Training takes minutes;
                         a gunicorn request has 180 s and a sync worker that
                         trains is a worker nobody can score with.

Layout under ML_JOBS_DIR (/data/jobs in the image) plus the active selection's
dir_suffix (/data/jobs_v6 under ML_SELECTION=v6; see selections.py):

    queued/<user>.json    waiting; one file per user, so a repeat POST is a no-op
    running/<user>.json   being trained (at most one: numprocs=1)
    status/<user>.json    last known state: queued | running | ready | failed
    staging/<job-id>/     enrollment_service's working dir, deleted per job

Every write is tmp-in-the-same-dir + os.replace, so a reader never sees half a
file. With numprocs=1 the trainer needs no lock. If more trainers are ever run,
take a per-user fcntl.flock BEFORE claiming a job: os.replace overwrites on
POSIX, so two trainers could both "claim" the same user.

WHY A JOB IS RETRIED HERE AND NOT BY NAV
----------------------------------------
NAV re-claims a failed user only after 10 MORE eligible sessions. That is right
for a refusal (the data was not good enough; wait for more), and wrong for a
fetch that hit a restarting NAV or a key that was not configured yet. So
transient errors (enrollment_service.Retryable) are re-queued with backoff and
only become `failed` after MAX_RETRIES.
"""

from __future__ import annotations

import datetime as _dt
import json
import logging
import os
import re
import shutil
import signal
import sys
import time


HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

# Puts mobile_navigation_core/ on sys.path, which is where selections.py and
# the rest of the ML engine live.
import mobile_navigation_core                            # noqa: E402,F401

import selections                                        # noqa: E402  stdlib only
from utils.config import setup_logging                   # noqa: E402

logger = logging.getLogger('train_jobs')

# Used for every file name built from a user id (here and in
# enrollment_service), and by app.py to validate the route.
USER_ID_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$')

IDLE_SLEEP_S = 5
MAX_RETRIES = 12                       # 60 s doubling to a 1 h cap: ~7 h in all
RETRY_BASE_S = 60
RETRY_CAP_S = 3600

QUEUED, RUNNING, READY, FAILED = 'queued', 'running', 'ready', 'failed'


def valid_user_id(user_id):
    return (isinstance(user_id, str) and bool(USER_ID_RE.match(user_id))
            and '..' not in user_id)


def jobs_dir():
    """ML_JOBS_DIR (default jobs) + the active selection's dir_suffix, so each
    selection profile has its own spool."""
    return selections.jobs_dir()


def _dirs(root=None):
    root = root or jobs_dir()
    return {name: os.path.join(root, name)
            for name in ('queued', 'running', 'status', 'staging')}


def _now():
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec='seconds')


def _write_json(path, obj):
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    tmp = os.path.join(folder, '.tmp.%s.%d' % (os.path.basename(path), os.getpid()))
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(obj, fh, sort_keys=True)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def _read_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _job_path(kind, user_id, root=None):
    return os.path.join(_dirs(root)[kind], '%s.json' % user_id)


# =============================================================================
#  the web side (app.py)
# =============================================================================

def status(user_id, root=None):
    """The user's status record, or None if no job was ever queued."""
    if not valid_user_id(user_id):
        raise ValueError('invalid user_id')
    return _read_json(_job_path('status', user_id, root))


def _set_status(user_id, state, attempt=None, reason=None, built_at=None,
                profile_id=None, root=None, **extra):
    record = {'user_id': user_id, 'state': state, 'attempt': attempt,
              'reason': reason, 'built_at': built_at, 'profile_id': profile_id,
              'updated_at': _now()}
    record.update(extra)
    _write_json(_job_path('status', user_id, root), record)
    return record


def enqueue(user_id, profile_id=None, attempt=None, root=None):
    """
    Queue a first enrolment. Returns the status record.

    A job already queued or running is left alone and its record returned, so a
    repeated POST (NAV re-posts when it finds no job) cannot start a second
    training. Two gunicorn workers racing here write the same file twice,
    which is harmless; a job queued just after the trainer claimed one runs
    once more and stops at "bundle exists".
    """
    if not valid_user_id(user_id):
        raise ValueError('invalid user_id')
    for kind, state in (('running', RUNNING), ('queued', QUEUED)):
        if os.path.exists(_job_path(kind, user_id, root)):
            return status(user_id, root) or {'user_id': user_id, 'state': state}

    job = {'user_id': user_id, 'profile_id': profile_id, 'attempt': attempt,
           'enqueued_at': _now(), 'retries': 0, 'not_before': 0}
    _write_json(_job_path('queued', user_id, root), job)
    return _set_status(user_id, QUEUED, attempt=attempt, profile_id=profile_id,
                       root=root)


# =============================================================================
#  the trainer side
# =============================================================================

class _Stop(Exception):
    pass


def _on_sigterm(signum, frame):              # noqa: ARG001
    # SystemExit, not a flag: a job in progress is abandoned (its staging dir
    # removed by enrollment_service's finally) and its running/ file stays, so
    # the next start re-queues it. supervisord's stopwaitsecs is 70 s, far less
    # than a training run, so waiting for the job is not an option.
    raise SystemExit(0)


def recover(root=None):
    """At start: running -> queued, and clear staging and tmp leftovers."""
    d = _dirs(root)
    for path in d.values():
        os.makedirs(path, exist_ok=True)
    for name in os.listdir(d['running']):
        if name.endswith('.json'):
            src = os.path.join(d['running'], name)
            dst = os.path.join(d['queued'], name)
            logger.warning('re-queueing orphaned job %s', name)
            os.replace(src, dst)
            job = _read_json(dst) or {}
            _set_status(job.get('user_id') or name[:-5], QUEUED,
                        attempt=job.get('attempt'),
                        profile_id=job.get('profile_id'),
                        reason='requeued after trainer restart', root=root)
    for name in os.listdir(d['staging']):
        shutil.rmtree(os.path.join(d['staging'], name), ignore_errors=True)
    for kind in ('queued', 'status', 'running'):
        for name in os.listdir(d[kind]):
            if name.startswith('.tmp.'):
                try:
                    os.remove(os.path.join(d[kind], name))
                except OSError:
                    pass


def _next_job(root=None):
    """(path, job) of the oldest queued job that is due, or (None, None)."""
    folder = _dirs(root)['queued']
    due = []
    now = time.time()
    for name in os.listdir(folder):
        if not name.endswith('.json') or name.startswith('.tmp.'):
            continue
        path = os.path.join(folder, name)
        job = _read_json(path)
        if not job or not valid_user_id(job.get('user_id')):
            logger.error('dropping unreadable job file %s', name)
            try:
                os.replace(path, path + '.bad')
            except OSError:
                pass
            continue
        if float(job.get('not_before') or 0) <= now:
            due.append((job.get('enqueued_at') or '', path, job))
    if not due:
        return None, None
    due.sort()
    return due[0][1], due[0][2]


def run_one(job, root=None, enrol=None):
    """Train one claimed job and record the outcome. Never raises Exception."""
    import enrollment_service as ES
    enrol = enrol or ES.enrol

    user_id = job['user_id']
    attempt, profile_id = job.get('attempt'), job.get('profile_id')
    job_id = '%s-%d-%d' % (user_id, int(time.time()), os.getpid())
    print('[TRAIN] %s: claimed job %s, state -> running' % (user_id, job_id), flush=True)
    _set_status(user_id, RUNNING, attempt=attempt, profile_id=profile_id,
                root=root, job_id=job_id)
    started = time.time()
    try:
        result = enrol(user_id, profile_id=profile_id, job_id=job_id)
    except ES.Refused as refusal:
        logger.warning('%s refused: %s', user_id, refusal)
        print('[TRAIN] %s: REFUSED -> state=failed reason=%s'
              % (user_id, refusal.reason), flush=True)
        return _set_status(user_id, FAILED, attempt=attempt,
                           profile_id=profile_id, root=root,
                           reason=refusal.reason[:1000])
    except ES.FetchError as error:
        # NAV answered and the answer settles it: no such profile, a mismatched
        # profile, a malformed page. Expected, not a bug - no traceback, and
        # never retried (the docstring on FetchError says so; retrying a
        # nonexistent profile just wastes MAX_RETRIES worth of backoff).
        logger.warning('%s: not enrolled - %s', user_id, error)
        print('[TRAIN] %s: NAV_REJECTED %s -> state=failed'
              % (user_id, error), flush=True)
        return _set_status(user_id, FAILED, attempt=attempt,
                           profile_id=profile_id, root=root,
                           reason=('nav_rejected:%s' % error)[:1000])
    except ES.Retryable as error:
        retries = int(job.get('retries') or 0) + 1
        if retries > MAX_RETRIES:
            logger.error('%s: giving up after %d retries: %s', user_id,
                         retries - 1, error)
            print('[TRAIN] %s: giving up after %d retries: %s -> state=failed'
                  % (user_id, retries - 1, error), flush=True)
            return _set_status(user_id, FAILED, attempt=attempt,
                               profile_id=profile_id, root=root,
                               reason=('error:%s' % error)[:1000])
        delay = min(RETRY_CAP_S, RETRY_BASE_S * 2 ** (retries - 1))
        logger.warning('%s: retry %d/%d in %ds: %s', user_id, retries,
                       MAX_RETRIES, delay, error)
        print('[TRAIN] %s: RETRYABLE error %s -> retry %d/%d in %ds'
              % (user_id, error, retries, MAX_RETRIES, delay), flush=True)
        job = dict(job, retries=retries, not_before=time.time() + delay)
        _write_json(_job_path('queued', user_id, root), job)
        return _set_status(user_id, QUEUED, attempt=attempt,
                           profile_id=profile_id, root=root,
                           reason=('retry:%s' % error)[:1000])
    except Exception as error:                           # noqa: BLE001
        logger.exception('%s: enrolment failed', user_id)
        print('[TRAIN] %s: UNEXPECTED error %s: %s -> state=failed'
              % (user_id, type(error).__name__, error), flush=True)
        return _set_status(user_id, FAILED, attempt=attempt,
                           profile_id=profile_id, root=root,
                           reason=('error:%s: %s' % (type(error).__name__,
                                                     error))[:1000])

    logger.info('%s: %s in %.0fs', user_id, result.get('published'),
                time.time() - started)
    print('[TRAIN] %s: %s in %.0fs, built_at=%s -> state=ready'
          % (user_id, result.get('published'), time.time() - started,
             result.get('built_at')), flush=True)
    return _set_status(user_id, READY, attempt=attempt, profile_id=profile_id,
                       root=root, built_at=result.get('built_at') or _now(),
                       reason=result.get('published'),
                       enrolment=result.get('enrolment'))


def main(argv=None):
    setup_logging()
    if HERE not in sys.path:
        sys.path.insert(0, HERE)

    # Refuse to train with an unverified feature tree, exactly like gunicorn
    # refuses to serve with one. A raise here is a supervisord restart, then
    # FATAL - which does NOT take the container down (quit_on_fatal only
    # watches gunicorn and nginx), so scoring carries on.
    from boot_checks import run_boot_checks
    run_boot_checks(strict=True)
    import enrollment_service as ES
    profile = ES.active_profile()
    ES.check_selection(profile)

    signal.signal(signal.SIGTERM, _on_sigterm)
    root = jobs_dir()
    recover(root)
    logger.info('trainer ready: selection=%s%s (%s) jobs=%s models=%s '
                'templates=%s nav=%s', profile['name'],
                ' [experimental]' if profile['experimental'] else '',
                profile['file'], root, ES.models_dir(), ES.templates_dir(),
                'configured' if ES.nav_base_url() else 'NOT CONFIGURED')

    while True:
        if not tick(root):
            time.sleep(IDLE_SLEEP_S)


def tick(root=None, enrol=None):
    """Claim and run the next due job. False when there was nothing to do."""
    running = job = None
    try:
        path, job = _next_job(root)
        if job is None:
            return False
        running = _job_path('running', job['user_id'], root)
        os.replace(path, running)
        run_one(job, root, enrol=enrol)
        # Only after a normal return. On SIGTERM (SystemExit) the running/
        # file must survive so recover() re-queues the job; a retried job was
        # already re-written to queued/ by run_one.
        os.remove(running)
        return True
    except Exception:                                    # noqa: BLE001
        # Never leave the loop on an error: supervisord's quit_on_fatal used
        # to turn a FATAL program into a dead container.
        logger.exception('trainer loop error')
        if running and os.path.exists(running):
            try:
                os.replace(running, _job_path('queued', job['user_id'], root))
            except OSError:
                pass
        return False


if __name__ == '__main__':
    sys.exit(main())
